# Copyright 2025 The PySCF Developers. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

try:
    from ase.calculators.calculator import Calculator, all_properties
except ImportError:
    print("""ASE is not found. Please install ASE via
pip3 install ase
          """)
    raise RuntimeError("ASE is not found")

import numpy as np
import cupy as cp
from ase.units import Debye
from pyscf import lib
from pyscf.data.nist import BOHR, HARTREE2EV
from pyscf.gto.mole import charge
from pyscf.pbc.gto.cell import Cell
from pyscf.pbc.tools.pyscf_ase import ase_atoms_to_pyscf

# These functions are copied from the development branch of PySCF and will be
# provided by the pyscf.pbc.tools.pyscf_ase module in PySCF 2.11.

def pyscf_to_ase_atoms(pyscf_obj):
    '''
    Convert PySCF Cell/Mole object to ASE Atoms object
    '''
    from ase import Atoms
    from pyscf.pbc import gto
    from pyscf.gto import mole

    if isinstance(pyscf_obj, mole.MoleBase):
        cell = pyscf_obj
        method = None
    elif hasattr(pyscf_obj, 'mol'):
        cell = pyscf_obj.mol
        method = pyscf_obj
    else:
        cell = pyscf_obj.cell
        method = pyscf_obj

    symbols = cell.elements
    positions = cell.atom_coords() * BOHR
    if isinstance(cell, gto.Cell):
        a = cell.lattice_vectors() * BOHR
        atoms = Atoms(symbols, positions, cell=a, pbc=True)
    else:
        atoms = Atoms(symbols, positions, pbc=False)

    if method is not None:
        atoms.calc = PySCF(method=method)
    return atoms

def cell_from_ase(ase_atoms):
    '''Convert ASE atoms to PySCF Cell instance. The lattice vectors and atomic
    positions are defined in the Cell instance. It does not have any basis sets
    or pseudopotentials assigned. The Cell instance is not initialized with 'build()'.
    '''
    cell = Cell()
    cell.atom = ase_atoms_to_pyscf(ase_atoms)
    cell.a = np.asarray(ase_atoms.cell)
    return cell

def bandpath(cell, npoints=None):
    from ase.cell import Cell as ase_Cell
    a = cell.lattice_vectors() * BOHR # To Angstrom
    bp = ase_Cell(a).bandpath(npoints=npoints)
    return bp

def plot_band_structure(bandpath, e_kn, ax=None, color='k'):
    '''
    Args:
        bandpath:
            an ase.BandPath instance
        e_kn:
            eigenvalus for each k-points (in eV)
        ax:
            matplotlib Axis instance
        color:
            color for band
    '''
    import matplotlib.pyplot as plt
    if ax is None:
        fig, ax = plt.subplots(figsize=(6, 4))

    xcoords, sp_points, sp_labels = bandpath.get_linear_kpoint_axis()

    nbands = e_kn.shape[1]
    for b in range(nbands):
        plt.plot(xcoords, e_kn[:,b], color=color, lw=1)

    for x in sp_points:
        ax.axvline(x, color="gray", linewidth=0.8)
    ax.set_xticks(sp_points)
    ax.set_xticklabels(sp_labels)

    ax.set_xlim(xcoords[0], xcoords[-1])
    ax.set_ylabel("Energy (eV)")
    ax.set_xlabel("k-vector")
    ax.set_title("Band Structure")
    ax.axhline(0.0, color="red", linestyle="--", linewidth=0.8)  # Fermi level
    return ax

class PySCF(Calculator):
    implemented_properties = ['energy', 'forces', 'stress',
                              'dipole', 'magmom']

    default_parameters = {}

    def __init__(self, restart=None, label='PySCF', atoms=None, directory='.',
                 method=None, **kwargs):
        """Construct PySCF-calculator object.

        Parameters
        ==========
        label: str
            Prefix to use for filenames (label.in, label.txt, ...).
            Default is 'PySCF'.

        method: A PySCF method class
        """
        Calculator.__init__(self, restart, label=label, atoms=atoms,
                            directory=directory, **kwargs)

        if not isinstance(method, lib.StreamObject):
            raise RuntimeError(f'{method} must be an instance of a PySCF method')

        self.method = method
        self.pbc = hasattr(method, 'cell')
        if self.pbc:
            mol = method.cell
        else:
            mol = method.mol
        self.mol = mol
        self.method_scan = None
        if hasattr(method, 'as_scanner'):
            # Scanner can utilize the initial guess from previous calculations
            self.method_scan = method.as_scanner()

    def set(self, **kwargs):
        changed_parameters = Calculator.set(self, **kwargs)
        if changed_parameters:
            self.reset()

    def calculate(self, atoms=None, properties=['energy'],
                  system_changes=all_properties):
        Calculator.calculate(self, atoms)

        positions = atoms.get_positions()
        atomic_numbers = atoms.get_atomic_numbers()
        Z = np.array([charge(x) for x in self.mol.elements])
        if all(Z == atomic_numbers):
            _atoms = positions
        else:
            _atoms = list(zip(atomic_numbers, positions))

        if self.pbc:
            self.mol.set_geom_(_atoms, a=np.asarray(atoms.cell), unit='Angstrom')
        else:
            self.mol.set_geom_(_atoms, unit='Angstrom')

        with_grad = 'forces' in properties or 'stress' in properties
        with_energy = with_grad or 'energy' in properties or 'dipole' in properties

        if with_energy:
            if self.method_scan is None:
                self.mol.set_geom_(atoms)
                self.method.reset(self.mol).run()
                e_tot = self.method.e_tot
                if not getattr(self.method, 'converged', True):
                    raise RuntimeError(f'{self.method} not converged')
            else:
                e_tot = self.method_scan(self.mol)
                if not self.method_scan.converged:
                    raise RuntimeError(f'{self.method} not converged')
            self.results['energy'] = e_tot * HARTREE2EV

        if self.method_scan is None:
            base_method = self.method
        else:
            base_method = self.method_scan

        if with_grad:
            grad_obj = base_method.Gradients()

        if 'forces' in properties:
            forces = -grad_obj.kernel()
            self.results['forces'] = forces * (HARTREE2EV / BOHR)

        if 'stress' in properties:
            stress = grad_obj.get_stress()
            self.results['stress'] = stress * (HARTREE2EV / BOHR)

        if 'dipole' in properties:
            if self.pbc:
                raise NotImplementedError('dipole for PBC calculations')
            # in Gaussian cgs unit
            self.results['dipole'] = base_method.dip_moment() * Debye

        if 'magmom' in properties:
            magmom = self.mol.spin
            self.results['magmom'] = magmom

    def get_fermi_level(self):
        method = self.method if self.method_scan is None else self.method_scan
        return method.get_fermi() * HARTREE2EV

    def get_eigenvalues(self, kpt=0, spin=0):
        method = self.method if self.method_scan is None else self.method_scan
        if method.istype('UHF'):
            e = method.mo_energy[spin]
        else:
            assert spin == 0
            e = method.mo_energy
        if method.istype('KSCF'):
            e = e[kpt]
        else:
            assert kpt == 0
        return e * HARTREE2EV

    def get_occupation_numbers(self, kpt=0, spin=0):
        method = self.method if self.method_scan is None else self.method_scan
        if method.istype('UHF'):
            occ = method.mo_occ[spin]
        else:
            assert spin == 0
            occ = method.mo_occ
        if method.istype('KSCF'):
            occ = occ[kpt]
        else:
            assert kpt == 0
        return occ

    def get_number_of_spins(self):
        method = self.method if self.method_scan is None else self.method_scan
        if method.istype('UHF'):
            nspins = 2
        else:
            nspins = 1
        return nspins

    def band_structure(self):
        """Create band-structure object for plotting."""
        from ase.spectrum.band_structure import get_band_structure, BandStructure
        method = self.method if self.method_scan is None else self.method_scan
        standard_path = self.atoms.cell.bandpath()
        band_kpts = method.cell.get_abs_kpts(standard_path.kpts)
        e_k = cp.asnumpy(cp.array(method.get_bands(band_kpts)[0]))
        if not method.istype('UHF'):
            e_k = e_k[None]
        fermi = self.get_fermi_level()
        return BandStructure(standard_path, e_k, fermi)
