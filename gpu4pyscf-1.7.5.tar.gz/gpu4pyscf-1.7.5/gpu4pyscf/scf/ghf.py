# Copyright 2021-2024 The PySCF Developers. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
import cupy as cp
from cupyx.scipy.linalg import block_diag
from pyscf.lib import PauliMatrices
from pyscf.scf import ghf as ghf_cpu
from pyscf.data.nist import HARTREE2EV
from gpu4pyscf.scf import hf
from gpu4pyscf.lib import logger
from gpu4pyscf.lib.cupy_helper import asarray, return_cupy_array
from gpu4pyscf.lib import utils

def _from_rhf_init_dm(dma, breaksym=True):
    dma = dma * .5
    dm = block_diag(dma, dma)
    if breaksym:
        nao = dma.shape[0]
        idx, idy = cp.diag_indices(nao)
        dm[idx+nao,idy] = dm[idx,idy+nao] = dma.diagonal() * .05
    return dm

class GHF(hf.SCF):
    to_gpu = utils.to_gpu
    device = utils.device

    with_soc = None
    _keys = {'with_soc'}

    scf = kernel = hf.RHF.kernel
    make_rdm2 = NotImplemented
    newton = NotImplemented
    x2c = x2c1e = sfx2c1e = NotImplemented
    to_rhf = NotImplemented
    to_uhf = NotImplemented
    to_ghf = NotImplemented
    to_rks = NotImplemented
    to_uks = NotImplemented
    to_gks = NotImplemented
    to_ks = NotImplemented
    canonicalize = NotImplemented
    # TODO: Enable followings after testing
    analyze = NotImplemented
    stability = NotImplemented
    mulliken_pop = NotImplemented
    mulliken_meta = NotImplemented

    get_grad = return_cupy_array(ghf_cpu.GHF.get_grad)
    energy_elec = hf.energy_elec

    def get_init_guess(self, mol=None, key='minao', **kwargs):
        dma = hf.RHF.get_init_guess(self, mol, key, **kwargs)
        return _from_rhf_init_dm(dma)

    def get_hcore(self, mol=None):
        if mol is None: mol = self.mol
        htmp = hf.get_hcore(mol)
        hcore = block_diag(htmp, htmp)

        if self.with_soc and mol.has_ecp_soc():
            # The ECP SOC contribution = <|1j * s * U_SOC|>
            s = .5 * PauliMatrices
            ecpso = np.einsum('sxy,spq->xpyq', -1j * s, mol.intor('ECPso'))
            # Convert to complex array
            hcore = hcore + asarray(ecpso.reshape(hcore.shape))
        return hcore

    def get_ovlp(self, mol=None):
        if mol is None: mol = self.mol
        stmp = hf.SCF.get_ovlp(self, mol)
        return block_diag(stmp, stmp)

    def get_jk(self, mol=None, dm=None, hermi=0, with_j=True, with_k=True,
               omega=None):
        vj = vk = None
        if with_j:
            vj = self.get_j(mol, dm, hermi, omega)
        if with_k:
            vk = self.get_k(mol, dm, hermi, omega)
        return vj, vk

    def get_j(self, mol=None, dm=None, hermi=1, omega=None):
        assert hermi == 1, 'hermi must be 1'
        dm = asarray(dm)
        dm_shape = dm.shape
        nso = dm.shape[-1]
        nao = nso // 2
        dm = dm.reshape(-1,nso,nso)
        n_dm = dm.shape[0]
        dm = dm[:,:nao,:nao] + dm[:,nao:,nao:]
        jtmp = hf.SCF.get_j(self, mol, dm.real, hermi, omega)
        vj = cp.zeros((n_dm,nso,nso), dtype=dm.dtype)
        vj[:,:nao,:nao] = vj[:,nao:,nao:] = jtmp
        return vj.reshape(dm_shape)

    def get_k(self, mol=None, dm=None, hermi=1, omega=None):
        dm = asarray(dm)
        dm_shape = dm.shape
        nso = dm.shape[-1]
        nao = nso // 2
        dm = dm.reshape(-1,nso,nso)
        n_dm = dm.shape[0]
        dmaa = dm[:,:nao,:nao]
        dmbb = dm[:,nao:,nao:]
        dmab = dm[:,:nao,nao:]
        dmba = dm[:,nao:,:nao]
        if dm.dtype == cp.complex128:
            dm_real = cp.vstack((dmaa.real, dmbb.real, dmab.real, dmba.real))
            ktmp_real = super().get_k(mol, dm_real, hermi=0, omega=omega)
            ktmp_real = ktmp_real.reshape(4,n_dm,nao,nao)
            dm_imag = cp.vstack((dmaa.imag, dmbb.imag, dmab.imag, dmba.imag))
            ktmp_imag = super().get_k(mol, dm_imag, hermi=0, omega=omega)
            ktmp_imag = ktmp_imag.reshape(4,n_dm,nao,nao)
            vk = cp.zeros((n_dm,nso,nso), dm.dtype)
            vk[:,:nao,:nao] = ktmp_real[0] + 1j*ktmp_imag[0]
            vk[:,nao:,nao:] = ktmp_real[1] + 1j*ktmp_imag[1]
            vk[:,:nao,nao:] = ktmp_real[2] + 1j*ktmp_imag[2]
            vk[:,nao:,:nao] = ktmp_real[3] + 1j*ktmp_imag[3]
        else:
            dm = cp.vstack((dmaa, dmbb, dmab, dmba))
            ktmp = super().get_k(mol, dm, hermi=0, omega=omega)
            ktmp = ktmp.reshape(4,n_dm,nao,nao)
            vk = cp.zeros((n_dm,nso,nso), dm.dtype)
            vk[:,:nao,:nao] = ktmp[0]
            vk[:,nao:,nao:] = ktmp[1]
            vk[:,:nao,nao:] = ktmp[2]
            vk[:,nao:,:nao] = ktmp[3]
        return vk.reshape(dm_shape)

    def get_veff(mf, mol=None, dm=None, dm_last=None, vhf_last=None, hermi=1):
        if dm is None: dm = mf.make_rdm1()
        if dm_last is not None and mf.direct_scf:
            dm = asarray(dm) - asarray(dm_last)
        vhf = mf.get_j(mol, dm, hermi)
        vk = mf.get_k(mol, dm, hermi)
        vhf -= vk
        if vhf_last is not None:
            vhf += asarray(vhf_last)
        return vhf

    def get_occ(self, mo_energy=None, mo_coeff=None):
        if mo_energy is None: mo_energy = self.mo_energy
        e_idx = cp.argsort(mo_energy.round(9))
        nmo = mo_energy.size
        mo_occ = cp.zeros_like(mo_energy)
        nocc = self.mol.nelectron
        if nocc > nmo:
            raise RuntimeError(f'Failed to assign mo_occ. Nocc ({nocc}) > Nmo ({nmo})')
        mo_occ[e_idx[:nocc]] = 1
        if self.verbose >= logger.INFO and nocc < nmo:
            homo, lumo = mo_energy[e_idx[nocc-1:nocc+1]].get()
            if homo+1e-3 > lumo:
                logger.warn(self, 'HOMO %.15g == LUMO %.15g', homo, lumo)
            else:
                logger.info(self, '  HOMO = %.15g  LUMO = %.15g  gap = %.5f eV',
                            homo, lumo, (lumo-homo)*HARTREE2EV)

        if mo_coeff is not None and self.verbose >= logger.DEBUG:
            ss, s = self.spin_square(mo_coeff[:,mo_occ>0], self.get_ovlp())
            logger.debug(self, 'multiplicity <S^2> = %.8g  2S+1 = %.8g', ss, s)
        return mo_occ

    def spin_square(self, mo, s=None):
        nao = mo.shape[0] // 2
        if s is not None:
            s = s[:nao,:nao]
        mo_a = mo[:nao]
        mo_b = mo[nao:]
        saa = mo_a.conj().T.dot(s).dot(mo_a)
        sbb = mo_b.conj().T.dot(s).dot(mo_b)
        sab = mo_a.conj().T.dot(s).dot(mo_b)
        sba = sab.conj().T
        nocc_a = saa.trace().real
        nocc_b = sbb.trace().real
        ssxy = (nocc_a+nocc_b) * .5
        ssxy+= (sba.trace() * sab.trace() - cp.einsum('ij,ji->', sba, sab)).real
        ssz  = (nocc_a+nocc_b) * .25
        ssz += (nocc_a-nocc_b)**2 * .25
        tmp  = saa - sbb
        ssz -= cp.einsum('ij,ji->', tmp, tmp).real * .25
        ss = float(ssxy.get()) + ssz
        s = (ss+.25)**.5 - .5
        return ss, s*2+1

    def to_cpu(self):
        mf = ghf_cpu.GHF(self.mol)
        utils.to_cpu(self, out=mf)
        return mf
