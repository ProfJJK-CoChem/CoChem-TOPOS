# Copyright 2021-2024 The PySCF Developers. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import sys
import functools
import ctypes
import numpy as np
import scipy.linalg
import cupy
from pyscf import lib
from gpu4pyscf.lib import logger
from gpu4pyscf.lib.cutensor import contract
from gpu4pyscf.lib import cusolver
from gpu4pyscf.lib.memcpy import copy_array, p2p_transfer  #NOQA
from gpu4pyscf.lib import multi_gpu
from gpu4pyscf.lib.utils import load_library
from gpu4pyscf.__config__ import num_devices, _p2p_access
from gpu4pyscf import __config__

LMAX_ON_GPU = 7
DSOLVE_LINDEP = 1e-13

# cusolver is unable to handle large arrays due to workspace size limit (see
# MAX_EIGH_DIM in cusolver.py). Use scipy.linalg.eigh to handle large arrays.
SCIPY_EIGH_FOR_LARGE_ARRAYS = True

_kernel_registery = {}

libcupy_helper = load_library('libcupy_helper')

pinned_memory_pool = cupy.cuda.PinnedMemoryPool()
cupy.cuda.set_pinned_memory_allocator(pinned_memory_pool.malloc)

def pin_memory(array):
    mem = cupy.cuda.alloc_pinned_memory(array.nbytes)
    ret = np.frombuffer(mem, array.dtype, array.size).reshape(array.shape)
    ret[...] = array
    return ret

def release_gpu_stack():
    cupy.cuda.runtime.deviceSetLimit(0x00, 128)

def print_mem_info():
    mempool = cupy.get_default_memory_pool()
    cupy.get_default_memory_pool().free_all_blocks()
    cupy.get_default_pinned_memory_pool().free_all_blocks()
    mem_avail = cupy.cuda.runtime.memGetInfo()[0]
    total_mem = mempool.total_bytes()
    used_mem = mempool.used_bytes()
    mem_limit = mempool.get_limit()
    #stack_size_per_thread = cupy.cuda.runtime.deviceGetLimit(0x00)
    #mem_stack = stack_size_per_thread
    GB = 1024 * 1024 * 1024
    msg = f'mem_avail: {mem_avail/GB:.3f} GB, total_mem: {total_mem/GB:.3f} GB, used_mem: {used_mem/GB:.3f} GB,mem_limt: {mem_limit/GB:.3f} GB'
    print(msg)
    return msg

def get_avail_mem(exclude_memory_pool=False):
    if exclude_memory_pool:
        return cupy.cuda.runtime.memGetInfo()[0]

    mempool = cupy.get_default_memory_pool()
    used_mem = mempool.used_bytes()
    mem_limit = mempool.get_limit()
    if(mem_limit != 0):
        return mem_limit - used_mem
    else:
        total_mem = mempool.total_bytes()
        # get memGetInfo() is slow
        mem_avail = cupy.cuda.runtime.memGetInfo()[0]
        return mem_avail + total_mem - used_mem

def concatenate(array_list):
    ''' Concatenate axis=0 only
    '''
    if _p2p_access:
        return cupy.concatenate(array_list)
    else:
        #array_list_cpu = [a.get() for a in array_list]
        n = sum([a.shape[0] for a in array_list])
        a0_shape = list(array_list[0].shape)
        out_shape = tuple([n] + a0_shape[1:])
        out = cupy.empty(out_shape)
        p0 = p1 = 0
        for a in array_list:
            p1 = p0 + a.shape[0]
            #out[p0:p1].set(a)
            copy_array(a, out[p0:p1])
            p0 = p1
        return out

def broadcast_to_devices():
    ''' Broadcast cupy ndarray to all the devices, return a list of cupy ndarray
    '''
    raise NotImplementedError

def reduce_to_device(array_list, inplace=False):
    ''' Reduce a list of ndarray in different devices to device 0
    '''
    return multi_gpu.array_reduce(array_list, inplace)

def device2host_2d(a_cpu, a_gpu, stream=None):
    if stream is None:
        stream = cupy.cuda.get_current_stream()
    libcupy_helper.async_d2h_2d(
        ctypes.cast(stream.ptr, ctypes.c_void_p),
        a_cpu.ctypes.data_as(ctypes.c_void_p),
        ctypes.c_int(a_cpu.strides[0]),
        ctypes.cast(a_gpu.data.ptr, ctypes.c_void_p),
        ctypes.c_int(a_gpu.strides[0]),
        ctypes.c_int(a_gpu.shape[0]),
        ctypes.c_int(a_gpu.shape[1]))

# define cupy array with tags
class CPArrayWithTag(cupy.ndarray):
    pass

#@functools.wraps(lib.tag_array)
def tag_array(a, **kwargs):
    '''
    a should be cupy/numpy array or tuple of cupy/numpy array

    attach attributes to cupy ndarray for cupy array
    attach attributes to numpy ndarray for numpy array
    '''
    if isinstance(a, cupy.ndarray) or isinstance(a[0], cupy.ndarray):
        t = cupy.asarray(a).view(CPArrayWithTag)
        if isinstance(a, CPArrayWithTag):
            t.__dict__.update(a.__dict__)
    else:
        t = np.asarray(a).view(lib.NPArrayWithTag)
        if isinstance(a, lib.NPArrayWithTag):
            t.__dict__.update(a.__dict__)
    t.__dict__.update(kwargs)
    return t

def asarray(a, **kwargs):
    '''
    Similar to `cupy.asarray`, but optimized for transferring NumPy arrays from host to device.
    If the input object is an instance of `CPArrayWithTag`, this function will remove any
    associated attributes from the tagged array during the transfer.

    Unlike `cupy.asarray`, which allocates a temporary buffer to avoid race conditions or
    host memory deallocation before transfer completion, this function
    eliminates that buffer for efficiency.
    '''
    if isinstance(a, np.ndarray):
        # CuPy always allocates pinned memory as a temporary buffer during array transfer.
        # This leads to additional memory usage, and the buffer is not managed by CuPy's
        # memory pool or Python's GC.
        # See the `cdef _ndarray_base _array_default` function in
        # cupy/_core/core.pyx, where memory buffer is allocated via
        # mem = _alloc_async_transfer_buffer(nbytes)

        allow_fast_transfer = kwargs.get('dtype', a.dtype) == a.dtype
        # a must be C-contiguous or F-contiguous
        if not a.flags.c_contiguous and not a.flags.f_contiguous:
            allow_fast_transfer = False
        if allow_fast_transfer:
            out = cupy.empty_like(a)
            out.set(a)
            if kwargs.get('blocking', False):
                cupy.cuda.get_current_stream().synchronize()
            return out

    elif isinstance(a, CPArrayWithTag):
        a = a.view(cupy.ndarray)

    return cupy.asarray(a, **kwargs)

ensure_numpy = cupy.asnumpy

def to_cupy(a):
    '''Converts a numpy (and subclass) object to a cupy object'''
    if isinstance(a, lib.NPArrayWithTag):
        attrs = {k: to_cupy(v) for k, v in a.__dict__.items()}
        return tag_array(cupy.asarray(a), **attrs)
    if isinstance(a, np.ndarray):
        return cupy.asarray(a)
    return a

def return_cupy_array(fn):
    '''Ensure that arrays in returns are cupy objects'''
    @functools.wraps(fn)
    def filter_ret(*args, **kwargs):
        ret = fn(*args, **kwargs)
        if isinstance(ret, tuple):
            return tuple(to_cupy(x) for x in ret)
        return to_cupy(ret)
    return filter_ret

def pack_tril(a, stream=None):
    ndim = a.ndim
    assert ndim in (2, 3)
    if ndim == 2:
        a = a[None]

    counts, n = a.shape[:2]
    if a.dtype != np.float64 or not a.flags.c_contiguous:
        idx = cupy.arange(n)
        mask = idx[:,None] >= idx
        a_tril = a[:,mask]
    else:
        if stream is None:
            stream = cupy.cuda.get_current_stream()
        a_tril = cupy.empty((counts, n*(n+1)//2), dtype=np.float64)
        err = libcupy_helper.pack_tril(
            ctypes.cast(stream.ptr, ctypes.c_void_p),
            ctypes.cast(a_tril.data.ptr, ctypes.c_void_p),
            ctypes.cast(a.data.ptr, ctypes.c_void_p),
            ctypes.c_int(n), ctypes.c_int(counts))
        if err != 0:
            raise RuntimeError('pack_tril kernel failed')

    if ndim == 2:
        a_tril = a_tril[0]
    return a_tril

def unpack_tril(cderi_tril, out=None, stream=None, hermi=1):
    assert cderi_tril.flags.c_contiguous
    assert hermi in (1, 2)
    ndim = cderi_tril.ndim
    assert ndim in (1, 2)
    if ndim == 1:
        cderi_tril = cderi_tril[None]
    count = cderi_tril.shape[0]
    nao = int((2*cderi_tril.shape[1])**.5)
    out = ndarray((count,nao,nao), dtype=cderi_tril.dtype, buffer=out)

    if cderi_tril.dtype != np.float64:
        idx = cupy.arange(nao)
        mask = idx[:,None] >= idx
        cderiT = out.transpose(0,2,1)
        if hermi == 1:
            cderiT[:,mask] = cderi_tril.conj()
        else:
            raise NotImplementedError
        out [:,mask] = cderi_tril
        return out

    if stream is None:
        stream = cupy.cuda.get_current_stream()
    err = libcupy_helper.unpack_tril(
        ctypes.cast(stream.ptr, ctypes.c_void_p),
        ctypes.cast(cderi_tril.data.ptr, ctypes.c_void_p),
        ctypes.cast(out.data.ptr, ctypes.c_void_p),
        ctypes.c_int(nao),
        ctypes.c_int(count),
        ctypes.c_int(hermi))
    if err != 0:
        raise RuntimeError('failed in unpack_tril kernel')
    if ndim == 1:
        out = out[0]
    return out

def unpack_sparse(cderi_sparse, row, col, p0, p1, nao, out=None, stream=None):
    if stream is None:
        stream = cupy.cuda.get_current_stream()
    if out is None:
        out = cupy.zeros([nao,nao,p1-p0])
    nij = len(row)
    naux = cderi_sparse.shape[1]
    nao = out.shape[1]
    err = libcupy_helper.unpack_sparse(
        ctypes.cast(stream.ptr, ctypes.c_void_p),
        ctypes.cast(cderi_sparse.data.ptr, ctypes.c_void_p),
        ctypes.cast(row.data.ptr, ctypes.c_void_p),
        ctypes.cast(col.data.ptr, ctypes.c_void_p),
        ctypes.cast(out.data.ptr, ctypes.c_void_p),
        ctypes.c_int(nao),
        ctypes.c_int(nij),
        ctypes.c_int(naux),
        ctypes.c_int(p0),
        ctypes.c_int(p1)
    )
    if err != 0:
        raise RuntimeError('failed in unpack_sparse')
    return out

def add_sparse(a, b, indices):
    '''
    a[:,...,:np.ix_(indices, indices)] += b
    '''
    assert a.device == b.device
    assert a.flags.c_contiguous
    assert b.flags.c_contiguous
    if len(indices) == 0: return a
    indices = cupy.asarray(indices, dtype=np.int32)
    n = a.shape[-1]
    m = b.shape[-1]
    if a.ndim > 2:
        count = np.prod(a.shape[:-2])
    elif a.ndim == 2:
        count = 1
    else:
        raise RuntimeError('add_sparse only supports 2d or 3d tensor')

    stream = cupy.cuda.get_current_stream()
    err = libcupy_helper.add_sparse(
        ctypes.cast(stream.ptr, ctypes.c_void_p),
        ctypes.cast(a.data.ptr, ctypes.c_void_p),
        ctypes.cast(b.data.ptr, ctypes.c_void_p),
        ctypes.cast(indices.data.ptr, ctypes.c_void_p),
        ctypes.c_int(n),
        ctypes.c_int(m),
        ctypes.c_int(count)
    )
    if err != 0:
        raise RuntimeError('failed in sparse_add2d')
    return a

def dist_matrix(x, y, out=None):
    '''np.linalg.norm(x[:,None,:] - y[None,:,:], axis=2)'''
    x = cupy.asarray(x, dtype=np.float64)
    y = cupy.asarray(y, dtype=np.float64)
    assert x.flags.c_contiguous
    assert y.flags.c_contiguous

    m = x.shape[0]
    n = y.shape[0]
    out = ndarray([m,n], buffer=out)

    stream = cupy.cuda.get_current_stream()
    err = libcupy_helper.dist_matrix(
        ctypes.cast(stream.ptr, ctypes.c_void_p),
        ctypes.cast(out.data.ptr, ctypes.c_void_p),
        ctypes.cast(x.data.ptr, ctypes.c_void_p),
        ctypes.cast(y.data.ptr, ctypes.c_void_p),
        ctypes.c_int(m),
        ctypes.c_int(n)
    )
    if err != 0:
        raise RuntimeError('failed in calculating distance matrix')
    return out

@multi_gpu.lru_cache(1)
def _initialize_c2s_data():
    from gpu4pyscf.gto import mole
    c2s_l = [mole.cart2sph_by_l(l) for l in range(LMAX_ON_GPU)]
    c2s_data = cupy.concatenate([x.ravel() for x in c2s_l])
    c2s_offset = np.cumsum([0] + [x.shape[0]*x.shape[1] for x in c2s_l])
    return c2s_l, c2s_data, c2s_offset

def block_c2s_diag(angular, counts):
    '''
    Diagonal blocked cartesian to spherical transformation
    Args:
        angular (list): angular momentum type, e.g. [0,1,2,3]
        counts (list): count of each angular momentum
    '''
    c2s_l, c2s_data, c2s_offset = _initialize_c2s_data()

    nshells = np.sum(counts)
    rows = [np.array([0], dtype='int32')]
    cols = [np.array([0], dtype='int32')]
    offsets = []
    for l, count in zip(angular, counts):
        r, c = c2s_l[l].shape
        rows.append(rows[-1][-1] + np.arange(1,count+1, dtype='int32') * r)
        cols.append(cols[-1][-1] + np.arange(1,count+1, dtype='int32') * c)
        offsets += [c2s_offset[l]] * count
    rows = cupy.hstack(rows)
    cols = cupy.hstack(cols)

    ncart, nsph = int(rows[-1]), int(cols[-1])
    cart2sph = cupy.zeros([ncart, nsph])
    offsets = cupy.asarray(offsets, dtype='int32')

    stream = cupy.cuda.get_current_stream()
    err = libcupy_helper.block_diag(
        ctypes.cast(stream.ptr, ctypes.c_void_p),
        ctypes.cast(cart2sph.data.ptr, ctypes.c_void_p),
        ctypes.c_int(ncart),
        ctypes.c_int(nsph),
        ctypes.cast(c2s_data.data.ptr, ctypes.c_void_p),
        ctypes.c_int(nshells),
        ctypes.cast(offsets.data.ptr, ctypes.c_void_p),
        ctypes.cast(rows.data.ptr, ctypes.c_void_p),
        ctypes.cast(cols.data.ptr, ctypes.c_void_p),
    )
    if err != 0:
        raise RuntimeError('failed in block_diag kernel')
    return cart2sph

def block_diag(blocks, out=None):
    '''
    each block size is up to 16x16
    '''
    rows = np.cumsum(np.asarray([0] + [x.shape[0] for x in blocks]))
    cols = np.cumsum(np.asarray([0] + [x.shape[1] for x in blocks]))
    offsets = np.cumsum(np.asarray([0] + [x.shape[0]*x.shape[1] for x in blocks]))

    m, n = rows[-1], cols[-1]
    if out is None: out = cupy.zeros([m, n])
    rows = cupy.asarray(rows, dtype='int32')
    cols = cupy.asarray(cols, dtype='int32')
    offsets = cupy.asarray(offsets, dtype='int32')
    data = cupy.concatenate([x.ravel() for x in blocks])
    stream = cupy.cuda.get_current_stream()
    err = libcupy_helper.block_diag(
        ctypes.cast(stream.ptr, ctypes.c_void_p),
        ctypes.cast(out.data.ptr, ctypes.c_void_p),
        ctypes.c_int(m),
        ctypes.c_int(n),
        ctypes.cast(data.data.ptr, ctypes.c_void_p),
        ctypes.c_int(len(blocks)),
        ctypes.cast(offsets.data.ptr, ctypes.c_void_p),
        ctypes.cast(rows.data.ptr, ctypes.c_void_p),
        ctypes.cast(cols.data.ptr, ctypes.c_void_p),
    )
    if err != 0:
        raise RuntimeError('failed in block_diag kernel')
    return out

def take_last2d(a, indices, out=None):
    '''
    Reorder the last 2 dimensions as a[..., indices[:,None], indices]
    '''
    assert a.flags.c_contiguous
    assert a.shape[-1] == a.shape[-2]
    nao = a.shape[-1]
    nidx = len(indices)
    if a.ndim == 2:
        count = 1
    else:
        count = np.prod(a.shape[:-2])
    out = ndarray((count, nidx, nidx), buffer=out)
    indices_int32 = cupy.asarray(indices, dtype='int32')
    stream = cupy.cuda.get_current_stream()
    err = libcupy_helper.take_last2d(
        ctypes.cast(stream.ptr, ctypes.c_void_p),
        ctypes.cast(out.data.ptr, ctypes.c_void_p),
        ctypes.cast(a.data.ptr, ctypes.c_void_p),
        ctypes.cast(indices_int32.data.ptr, ctypes.c_void_p),
        ctypes.c_int(count),
        ctypes.c_int(nidx),
        ctypes.c_int(nao)
    )
    if err != 0:
        raise RuntimeError('failed in take_last2d kernel')
    if a.ndim == 2:
        out = out.reshape(nidx,nidx)
    return out

def takebak(out, a, indices, axis=-1):
    '''(experimental)
    Take elements from a NumPy array along an axis and write to CuPy array.
    out[..., indices] = a
    '''
    assert axis == -1
    assert isinstance(a, np.ndarray)
    assert isinstance(out, cupy.ndarray)
    assert out.ndim == a.ndim
    assert a.shape[-1] == len(indices)
    if a.ndim == 1:
        count = 1
    else:
        assert out.shape[:-1] == a.shape[:-1]
        count = np.prod(a.shape[:-1])
    n_a = a.shape[-1]
    n_o = out.shape[-1]
    indices_int32 = cupy.asarray(indices, dtype=cupy.int32)
    stream = cupy.cuda.get_current_stream()
    err = libcupy_helper.takebak(
        ctypes.c_void_p(stream.ptr),
        ctypes.c_void_p(out.data.ptr), a.ctypes,
        ctypes.c_void_p(indices_int32.data.ptr),
        ctypes.c_int(count), ctypes.c_int(n_o), ctypes.c_int(n_a)
    )
    if err != 0: # Not the mapped host memory
        out[...,indices] = cupy.asarray(a)
    return out

def transpose_sum(a, stream=None, inplace=True, hermi=1):
    '''
    perform
    a + a.transpose(0,2,1) for hermi=1 or
    a - a.transpose(0,2,1) hermi=2
    inplace
    '''
    if not inplace:
        a = cupy.copy(a, order='C')
    ndim = a.ndim
    assert hermi == 1 or hermi == 2
    assert isinstance(a, cupy.ndarray)
    assert a.flags.c_contiguous
    assert ndim == 2 or ndim == 3
    if ndim == 2:
        a = a[None]
    count, m, n = a.shape
    assert m == n
    out = a
    stream = cupy.cuda.get_current_stream()
    if a.dtype == np.float64:
        fn = libcupy_helper.transpose_dsum
    else:
        fn = libcupy_helper.transpose_zsum
    err = fn(ctypes.cast(stream.ptr, ctypes.c_void_p),
             ctypes.cast(a.data.ptr, ctypes.c_void_p),
             ctypes.c_int(n), ctypes.c_int(count), ctypes.c_int(hermi))
    if err != 0:
        raise RuntimeError('failed in transpose_sum kernel')
    if ndim == 2:
        out = out[0]
    return out

def hermi_triu(mat, hermi=1, inplace=True, stream=None):
    '''
    Use the elements of the lower triangular part to fill the upper triangular part.
    See also pyscf.lib.hermi_triu

    hermi=1 performs symmetric; hermi=2 performs anti-symmetric
    '''
    assert hermi in (1, 2)
    if inplace:
        assert mat.flags.c_contiguous
    else:
        mat = mat.copy('C')

    if mat.ndim == 2:
        n = mat.shape[0]
        counts = 1
    elif mat.ndim == 3:
        counts, n = mat.shape[:2]
    else:
        raise ValueError(f'dimension not supported {mat.ndim}')

    if mat.dtype == np.float64:
        dtype = 1
    elif mat.dtype == np.complex128:
        dtype = 2
    else:
        raise ValueError(f'{mat.ndim} type not supported')

    if stream is None:
        stream = cupy.cuda.get_current_stream()
    err = libcupy_helper.fill_triu(
        ctypes.cast(stream.ptr, ctypes.c_void_p),
        ctypes.cast(mat.data.ptr, ctypes.c_void_p),
        ctypes.c_int(n), ctypes.c_int(counts), ctypes.c_int(hermi),
        ctypes.c_int(dtype))
    if err != 0:
        raise RuntimeError('hermi_triu kernel failed')
    return mat

def cart2sph_cutensor(t, axis=0, ang=1, out=None):
    '''
    transform 'axis' of a tensor from cartesian basis into spherical basis with cutensor
    '''
    from gpu4pyscf.gto import mole
    if(ang <= 1):
        if(out is not None): out[:] = t
        return t
    size = list(t.shape)
    c2s = mole.cart2sph_by_l(ang)
    if(not t.flags['C_CONTIGUOUS']): t = cupy.asarray(t, order='C')
    li_size = c2s.shape
    nli = size[axis] // li_size[0]
    i0 = max(1, np.prod(size[:axis]))
    i3 = max(1, np.prod(size[axis+1:]))
    out_shape = size[:axis] + [nli*li_size[1]] + size[axis+1:]

    t_cart = t.reshape([i0*nli, li_size[0], i3])
    if(out is not None):
        out = out.reshape([i0*nli, li_size[1], i3])
    t_sph = contract('min,ip->mpn', t_cart, c2s, out=out)
    return t_sph.reshape(out_shape)

def cart2sph(t, axis=0, ang=1, out=None, stream=None):
    '''
    transform 'axis' of a tensor from cartesian basis into spherical basis
    '''
    from gpu4pyscf.gto import mole
    if(ang <= 1):
        if(out is not None): out[:] = t
        return t
    size = list(t.shape)
    c2s = mole.cart2sph_by_l(ang)
    if(not t.flags['C_CONTIGUOUS']): t = cupy.asarray(t, order='C')
    li_size = c2s.shape
    nli = size[axis] // li_size[0]
    i0 = max(1, np.prod(size[:axis]))
    i3 = max(1, np.prod(size[axis+1:]))
    out_shape = size[:axis] + [nli*li_size[1]] + size[axis+1:]

    t_cart = t.reshape([i0*nli, li_size[0], i3])
    if(out is not None):
        out = out.reshape([i0*nli, li_size[1], i3])
    else:
        out = cupy.empty(out_shape)
    count = i0*nli*i3
    if stream is None:
        stream = cupy.cuda.get_current_stream()
    err = libcupy_helper.cart2sph(
        ctypes.cast(stream.ptr, ctypes.c_void_p),
        ctypes.cast(t_cart.data.ptr, ctypes.c_void_p),
        ctypes.cast(out.data.ptr, ctypes.c_void_p),
        ctypes.c_int(i3),
        ctypes.c_int(count),
        ctypes.c_int(ang)
    )
    if err != 0:
        raise RuntimeError('failed in cart2sph kernel')
    return out.reshape(out_shape)

# a copy with modification from
# https://github.com/pyscf/pyscf/blob/9219058ac0a1bcdd8058166cad0fb9127b82e9bf/pyscf/lib/linalg_helper.py#L1536
def krylov(aop, b, x0=None, tol=1e-10, max_cycle=30, dot=cupy.dot,
           lindep=DSOLVE_LINDEP, callback=None, hermi=False,
           verbose=logger.WARN):
    r'''Krylov subspace method to solve  (1+a) x = b.  Ref:
    J. A. Pople et al, Int. J.  Quantum. Chem.  Symp. 13, 225 (1979).
    Args:
        aop : function(x) => array_like_x
            aop(x) to mimic the matrix vector multiplication :math:`\sum_{j}a_{ij} x_j`.
            The argument is a 1D array.  The returned value is a 1D array.
        b : a vector or a list of vectors
    Kwargs:
        x0 : 1D array
            Initial guess
        tol : float
            Tolerance to terminate the operation aop(x).
        max_cycle : int
            max number of iterations.
        lindep : float
            Linear dependency threshold.  The function is terminated when the
            smallest eigenvalue of the metric of the trial vectors is lower
            than this threshold.
        dot : function(x, y) => scalar
            Inner product
        callback : function(envs_dict) => None
            callback function takes one dict as the argument which is
            generated by the builtin function :func:`locals`, so that the
            callback function can access all local variables in the current
            environment.
    Returns:
        x : ndarray like b
    '''
    if isinstance(aop, cupy.ndarray) and aop.ndim == 2:
        return cupy.linalg.solve(aop+cupy.eye(aop.shape[0]), b)

    if isinstance(verbose, logger.Logger):
        log = verbose
    else:
        log = logger.Logger(sys.stdout, verbose)

    if not (isinstance(b, cupy.ndarray) and b.ndim == 1):
        b = cupy.asarray(b)

    if x0 is None:
        x1 = b
    else:
        b = b - (x0 + aop(x0))
        x1 = b
    if x1.ndim == 1:
        x1 = x1.reshape(1, x1.size)
    nroots, ndim = x1.shape
    x1, rmat = _stable_qr(x1, cupy.dot, lindep=lindep)
    if len(x1) == 0:
        return cupy.zeros_like(b)

    x1 *= rmat.diagonal()[:,None]

    innerprod = [rmat[i,i].real ** 2 for i in range(x1.shape[0])]
    max_innerprod = max(innerprod)

    if max_innerprod < lindep or max_innerprod < tol**2:
        if x0 is None:
            return cupy.zeros_like(b)
        else:
            return x0

    xs = []
    ax = []

    max_cycle = min(max_cycle, ndim)
    for cycle in range(max_cycle):
        axt = aop(x1)
        if axt.ndim == 1:
            axt = axt.reshape(1,ndim)
        xs.extend(x1)
        ax.extend(axt)
        if callable(callback):
            callback(cycle, xs, ax)
        x1 = axt.copy()
        for i in range(len(xs)):
            xsi = cupy.asarray(xs[i])
            w = cupy.dot(x1, xsi.conj()) / innerprod[i]
            x1 -= xsi * cupy.expand_dims(w,-1)
        axt = xsi = None
        x1, rmat = _stable_qr(x1, cupy.dot, lindep=lindep)
        x1 *= rmat.diagonal()[:,None]
        innerprod1 = rmat.diagonal().real ** 2
        max_innerprod = max(innerprod1, default=0.)

        log.info(f'krylov cycle {cycle}, r = {max_innerprod**.5:.3e}, {x1.shape[0]} equations')
        if max_innerprod < lindep or max_innerprod < tol**2:
            break
        mask = (innerprod1 > lindep) & (innerprod1 > tol**2)
        x1 = x1[mask]
        innerprod.extend(innerprod1[mask])
        if max_innerprod > 1e10:
            raise RuntimeError('Krylov subspace iterations diverge')

    else:
        raise RuntimeError('Krylov solver failed to converge')

    log.info(f'krylov space size {len(xs)}')
    xs = cupy.asarray(xs)
    ax = cupy.asarray(ax)
    nd = xs.shape[0]

    h = cupy.dot(xs, ax.T)

    # Add the contribution of I in (1+a)
    h += cupy.diag(cupy.asarray(innerprod[:nd]))
    g = cupy.zeros((nd,nroots), dtype=x1.dtype)

    if b.ndim == 1:
        g[0] = innerprod[0]
    else:
        # Restore the first nroots vectors, which are array b or b-(1+a)x0
        for i in range(min(nd, nroots)):
            xsi = cupy.asarray(xs[i])
            g[i] = cupy.dot(xsi.conj(), b.T)

    c = cupy.linalg.solve(h, g)
    x = _gen_x0(c, cupy.asarray(xs))
    if b.ndim == 1:
        x = x[0]

    if x0 is not None:
        x += x0
    return x

def _qr(xs, dot, lindep=1e-14):
    '''QR decomposition for a list of vectors (for linearly independent vectors only).
    xs = (r.T).dot(qs)
    '''
    nvec = len(xs)
    dtype = xs[0].dtype
    qs = cupy.empty((nvec,xs[0].size), dtype=dtype)
    rmat = cupy.eye(nvec, order='F', dtype=dtype)

    nv = 0
    for i in range(nvec):
        xi = cupy.array(xs[i], copy=True)
        prod = dot(qs[:nv].conj(), xi)
        xi -= cupy.dot(qs[:nv].T, prod)

        innerprod = dot(xi.conj(), xi).real
        norm = innerprod**0.5
        if innerprod > lindep:
            rmat[:,nv] -= cupy.dot(rmat[:,:nv], prod)
            qs[nv] = xi/norm
            rmat[:nv+1,nv] /= norm
            nv += 1
    return qs[:nv], cupy.linalg.inv(rmat[:nv,:nv])

def _stable_qr(xs, dot, lindep=1e-14):
    '''QR decomposition for a list of vectors (for linearly independent vectors only).
    using the modified Gram-Schmidt process
    '''
    nvec = len(xs)
    dtype = xs[0].dtype
    Q = cupy.empty((nvec,xs[0].size), dtype=dtype)
    R = cupy.zeros((nvec,nvec), dtype=dtype)
    V = xs.copy()
    nv = 0
    for i in range(nvec):
        norm = cupy.linalg.norm(V[i])
        if norm**2 > lindep:
            R[nv,nv] = norm
            Q[nv] = V[i] / norm
            R[nv, i+1:] = dot(Q[nv], V[i+1:].T)
            V[i+1:] -= cupy.outer(R[nv, i+1:], Q[nv])
            nv += 1
    return Q[:nv], R[:nv,:nv]

def _gen_x0(v, xs):
    ndim = v.ndim
    if ndim == 1:
        v = v[:,None]
    space, nroots = v.shape
    x0 = cupy.einsum('c,x->cx', v[space-1], cupy.asarray(xs[space-1]))
    for i in reversed(range(space-1)):
        xsi = cupy.asarray(xs[i])
        x0 += cupy.expand_dims(v[i],-1) * xsi
    if ndim == 1:
        x0 = x0[0]
    return x0

_MAX_MEMORY = os.getenv('PYSCF_MAX_MEMORY')
if _MAX_MEMORY is None and __config__.MAX_MEMORY != 4000:
    # 4000 MB is the built-in default initialized in pyscf.__config__.
    # If MAX_MEMORY has been explicitly configured (e.g. in ~/.pyscf_conf.py),
    # use that value when the environment variable is not set.
    _MAX_MEMORY = __config__.MAX_MEMORY

def empty_mapped(shape, dtype=float, order='C'):
    '''(experimental)
    Returns a new, uninitialized NumPy array with the given shape and dtype.

    This is a convenience function which is just :func:`numpy.empty`,
    except that the underlying buffer is a pinned and mapped memory.
    This array can be used as the buffer of zero-copy memory.
    '''
    size = int(np.prod(shape))
    nbytes = size * int(np.dtype(dtype).itemsize)
    assert nbytes >= 0, f"nbytes = {nbytes} is negative, type(nbytes) = {type(nbytes)}, please check if overflow happens"

    if _MAX_MEMORY is not None:
        mem_used = lib.current_memory()[0] # in MB
        mem_limit = float(_MAX_MEMORY)
        if nbytes*1e-6 + mem_used > mem_limit:
            raise MemoryError(
                f'Cannot allocate {nbytes} bytes of host memory '
                f'(current: {mem_used:.1f} MB, limit: {mem_limit:.1f} MB).')

    mem = cupy.cuda.PinnedMemoryPointer(
        cupy.cuda.PinnedMemory(nbytes, cupy.cuda.runtime.hostAllocMapped), 0)
    out = np.ndarray(shape, dtype=dtype, buffer=mem, order=order)
    return out

def ndarray(shape, dtype=np.float64, buffer=None):
    '''
    Construct CuPy ndarray object using the NumPy ndarray API

    Args:
        shape : tuple or int
            Shape of the array to allocate.

    Kwargs:
        dtype : Numpy data type.

        buffer : CuPy array or CuPy memory object
            If buffer is specified, used to fill the array. Otherwise, a new
            memory space will be allocated to store data.
    '''
    if buffer is None:
        return cupy.empty(shape, dtype)
    else:
        out = cupy.ndarray(shape, dtype, memptr=buffer.data)
        assert buffer.nbytes >= out.nbytes
        return out

def pinv(a, lindep=1e-10):
    '''psudo-inverse with eigh, to be consistent with pyscf
    '''
    a = cupy.asarray(a)
    w, v = eigh(a)
    mask = w > lindep
    v1 = v[:,mask]
    j2c = cupy.dot(v1/w[mask], v1.conj().T)
    return j2c

def cond(a, sympos=False, verbose=logger.WARN):
    """
    Calculate the condition number of a matrix.

    Parameters:
    a (cupy.ndarray): The input matrix.
    sympos : Whether the input matrix is symmetric and positive definite.

    Returns:
    float: The condition number of the matrix.
    """
    if isinstance(verbose, logger.Logger):
        log = verbose
    else:
        log = logger.Logger(sys.stdout, verbose)

    if a.shape[0] > cusolver.MAX_EIGH_DIM:
        if not SCIPY_EIGH_FOR_LARGE_ARRAYS:
            raise RuntimeError(
                f'Array size exceeds the maximum size {cusolver.MAX_EIGH_DIM}.')
        a = a.get()
        if sympos:
            s = scipy.linalg.eigvalsh(a)
            if s[0] > 0:
                return s[-1] / s[0]
            else:
                log.warn(f'In condition number calculation, matrix is assumed to be positive definite, but it is not (minimal eigenvalue = {s[0]:e})')
        _, s, _ = scipy.linalg.svd(a)
        cond_number = s[0] / s[-1]
        return cond_number

    else:
        if sympos:
            s = cupy.linalg.eigvalsh(a)
            if s[0] > 0:
                return s[-1] / s[0]
            else:
                log.warn(f'In condition number calculation, matrix is assumed to be positive definite, but it is not (minimal eigenvalue = {s[0]:e})')
        _, s, _ = cupy.linalg.svd(a)
        cond_number = s[0] / s[-1]
        return cond_number

def grouped_dot(As, Bs, Cs=None):
    '''
    todo: layout of cutlass kernel
    As: cupy 2D array list.
    Bs: cupy 2D array list.
    Cs: cupy 2D array list.
    einsum('ik,jk->ij', A, B, C) C=A@B.T
    '''
    assert len(As) > 0
    assert len(As) == len(Bs)
    assert As[0].flags.c_contiguous
    assert Bs[0].flags.c_contiguous
    groups = len(As)
    Ms, Ns, Ks = [], [], []
    for a, b in zip(As, Bs):
        Ms.append(a.shape[0])
        Ns.append(b.shape[0])
        Ks.append(a.shape[1])

    if Cs is None:
        Cs = []
        for i in range(groups):
            Cs.append(cupy.empty((Ms[i], Ns[i])))

    As_ptr, Bs_ptr, Cs_ptr = [], [], []
    for a, b, c in zip(As, Bs, Cs):
        As_ptr.append(a.data.ptr)
        Bs_ptr.append(b.data.ptr)
        Cs_ptr.append(c.data.ptr)

    As_ptr = np.array(As_ptr)
    Bs_ptr = np.array(Bs_ptr)
    Cs_ptr = np.array(Cs_ptr)

    Ms = np.array(Ms)
    Ns = np.array(Ns)
    Ks = np.array(Ks)
    total_size = 68 * groups
    '''
    68 is the result of
    sizeof(cutlass::gemm::GemmCoord) +
    sizeof(typename DeviceKernel::ElementA*) +
    sizeof(typename DeviceKernel::ElementB*) +
    sizeof(typename DeviceKernel::ElementC*) +
    sizeof(typename DeviceKernel::ElementC*) +
    sizeof(int64_t) + sizeof(int64_t) + sizeof(int64_t)
    '''
    padding = 8 - (total_size % 8)
    total_size += padding
    cutlass_space = cupy.empty(total_size, dtype=cupy.uint8)

    stream = cupy.cuda.get_current_stream()
    err = libcupy_helper.grouped_dot(
        ctypes.cast(stream.ptr, ctypes.c_void_p),
        ctypes.cast(Cs_ptr.ctypes.data, ctypes.c_void_p),
        ctypes.cast(As_ptr.ctypes.data, ctypes.c_void_p),
        ctypes.cast(Bs_ptr.ctypes.data, ctypes.c_void_p),
        ctypes.cast(Ms.ctypes.data, ctypes.c_void_p),
        ctypes.cast(Ns.ctypes.data, ctypes.c_void_p),
        ctypes.cast(Ks.ctypes.data, ctypes.c_void_p),
        ctypes.cast(cutlass_space.data.ptr, ctypes.c_void_p),
        ctypes.c_int(groups)
    )
    if err != 0:
        raise RuntimeError('failed in grouped_gemm kernel')
    return Cs

def grouped_gemm(As, Bs, Cs=None):
    '''
    As: cupy 2D array list.
    Bs: cupy 2D array list.
    Cs: cupy 2D array list.
    assuming (X, 64).T @ (X, Y)
    einsum('ki,kj->ij', A, B, C) C=A.T@B
    Compare with grouped_dot, this function handles the case M < 128
    '''
    assert len(As) > 0
    assert len(As) == len(Bs)
    assert As[0].flags.c_contiguous
    assert Bs[0].flags.c_contiguous
    groups = len(As)
    Ms, Ns, Ks = [], [], []
    for a, b in zip(As, Bs):
        Ms.append(a.shape[1])
        Ns.append(b.shape[1])
        Ks.append(a.shape[0])

    if Cs is None:
        Cs = []
        for i in range(groups):
            Cs.append(cupy.empty((Ms[i], Ns[i])))

    As_ptr, Bs_ptr, Cs_ptr = [], [], []
    for a, b, c in zip(As, Bs, Cs):
        As_ptr.append(a.data.ptr)
        Bs_ptr.append(b.data.ptr)
        Cs_ptr.append(c.data.ptr)
    As_ptr = np.array(As_ptr)
    Bs_ptr = np.array(Bs_ptr)
    Cs_ptr = np.array(Cs_ptr)

    Ms = np.array(Ms)
    Ns = np.array(Ns)
    Ks = np.array(Ks)

    stream = cupy.cuda.get_current_stream()
    err = libcupy_helper.grouped_gemm(
        ctypes.cast(stream.ptr, ctypes.c_void_p),
        ctypes.cast(Cs_ptr.ctypes.data, ctypes.c_void_p),
        ctypes.cast(As_ptr.ctypes.data, ctypes.c_void_p),
        ctypes.cast(Bs_ptr.ctypes.data, ctypes.c_void_p),
        ctypes.cast(Ms.ctypes.data, ctypes.c_void_p),
        ctypes.cast(Ns.ctypes.data, ctypes.c_void_p),
        ctypes.cast(Ks.ctypes.data, ctypes.c_void_p),
        ctypes.c_int(groups)
    )
    if err != 0:
        raise RuntimeError('failed in grouped_gemm kernel')
    return Cs

def absmax(a):
    '''abs(a).max() while limiting temporary memory use. The optimization is
    only valid for real-valued arrays.
    '''
    if a.dtype == np.complex128 or a.nbytes < 100000000:
        return abs(a).max()
    return max(a.max(), -a.min())

def condense(opname, a, loc_x, loc_y=None):
    '''Aggregate the last two dimensions of an array using the specified operation.

    .. code-block:: python

        for i,i0 in enumerate(loc_x[:-1]):
            i1 = loc_x[i+1]
            for j,j0 in enumerate(loc_y[:-1]):
                j1 = loc_y[j+1]
                out[i,j] = op(a[..., i0:i1, j0:j1])
    '''
    assert opname in ('sum', 'max', 'min', 'abssum', 'absmax', 'norm')
    assert a.dtype == np.float64
    assert a.ndim >= 2
    if loc_y is None:
        loc_y = loc_x
    do_transpose = False
    if a.ndim == 2:
        if a.flags.f_contiguous:
            a = a.T
            loc_x, loc_y = loc_y, loc_x
            do_transpose = True
        a = a[None]
    else:
        nx, ny = a.shape[-2:]
        a = a.reshape(-1, nx, ny)
    a = cupy.asarray(a, order='C')
    loc_x = cupy.asarray(loc_x, cupy.int32)
    loc_y = cupy.asarray(loc_y, cupy.int32)
    nloc_x = loc_x.size - 1
    nloc_y = loc_y.size - 1
    counts, nx, ny = a.shape
    assert loc_x[-1] == nx
    assert loc_y[-1] == ny

    #if opname == 'absmax':
    #    out = cupy.zeros((nloc_x, nloc_y))
    #    err = libcupy_helper.dabsmax_condense(
    #        ctypes.cast(out.ctypes.data, ctypes.c_void_p),
    #        ctypes.cast(a.ctypes.data, ctypes.c_void_p),
    #        ctypes.cast(loc_x.ctypes.data, ctypes.c_void_p),
    #        ctypes.cast(loc_y.ctypes.data, ctypes.c_void_p),
    #        ctypes.c_int(nloc_x), ctypes.c_int(nloc_y), ctypes.c_int(counts))
    #    if err != 0:
    #        raise RuntimeError('failed in dabsmax_condense kernel')
    #    if do_transpose:
    #        out = out.T
    #    return out

    fn_name = f'd{opname}_condense'
    if fn_name not in _kernel_registery:
        if opname == 'sum':
            init_code = '0'
            code = 'val += a[ip*nj+jp];'
            result_code = 'val'
        elif opname == 'max':
            init_code = '0'
            code = 'double tmp = a[ip*nj+jp]; val = (val > tmp) ? val : tmp;'
            result_code = 'val'
        elif opname == 'min':
            init_code = '0'
            code = 'double tmp = a[ip*nj+jp]; val = (val < tmp) ? val : tmp;'
            result_code = 'val'
        elif opname == 'abssum':
            init_code = '0'
            code = 'val += fabs(a[ip*nj+jp]);'
            result_code = 'val'
        elif opname == 'absmax':
            init_code = '0'
            code = 'double tmp = fabs(a[ip*nj+jp]); val = (val > tmp) ? val : tmp;'
            result_code = 'val'
        elif opname == 'norm':
            init_code = '0'
            code = 'double tmp = a[ip*nj+jp]; val += tmp * tmp;'
            result_code = 'fsqrt(val)'

        kernel_code = ('''\
extern "C" __global__
void ''' + fn_name + '''(double *out, double *a, int *loc_x, int *loc_y,
        long long nloc_x, long long nloc_y, long long counts)
{
    int blocks_y = (nloc_y + 15) / 16;
    int i = (blockIdx.x / blocks_y) * 16 + threadIdx.y;
    int j = (blockIdx.x % blocks_y) * 16 + threadIdx.x;
    if (i >= nloc_x || j >= nloc_y) {
        return;
    }
    size_t ni = loc_x[nloc_x];
    size_t nj = loc_y[nloc_y];
    size_t Nloc_y = nloc_y;
    int i0 = loc_x[i];
    int i1 = loc_x[i+1];
    int j0 = loc_y[j];
    int j1 = loc_y[j+1];
    double val = ''' + init_code + ''';
    for (int n = 0; n < counts; ++n) {
        for (int ip = i0; ip < i1; ++ip) {
        for (int jp = j0; jp < j1; ++jp) {
            ''' + code + '''
        } }
        a += ni * nj;
    }
    out[i*Nloc_y+j] = ''' + result_code + ''';
}
''')
        _kernel_registery[fn_name] = cupy.RawKernel(kernel_code, fn_name)

    kernel = _kernel_registery[fn_name]
    out = cupy.zeros((nloc_x, nloc_y))
    blocks_x = (nloc_x + 15) // 16
    blocks_y = (nloc_y + 15) // 16
    blocks = (blocks_x * blocks_y,)
    threads = (16, 16)
    kernel(blocks, threads, (out, a, loc_x, loc_y, nloc_x, nloc_y, counts))
    if do_transpose:
        out = out.T
    return out

def sandwich_dot(a, c, out=None):
    '''Performs c.T.dot(a).dot(c)'''
    a = cupy.asarray(a)
    c = cupy.asarray(c)
    a_ndim = a.ndim
    if a_ndim == 2:
        a = a[None]
    counts = a.shape[0]
    m = c.shape[1]
    dtype = np.result_type(a, c)
    out = cupy.empty((counts, m, m), dtype=dtype)
    tmp = None
    for i in range(counts):
        tmp = cupy.dot(c.conj().T, a[i], out=tmp)
        cupy.dot(tmp, c, out=out[i])
    if a_ndim == 2:
        out = out[0]
    return out

def set_conditional_mempool_malloc(n_bytes_threshold=100000000):
    '''
    Customize CuPy memory allocator.

    For large memory allocations (>100MB by default), the custom allocator bypasses
    the CuPy memory pool, directly calling the CUDA malloc API. The large memory
    chunks will be released back to the system when the associated object is
    destroyed. Only small memory blocks are allocated from the CuPy memory pool.

    Execute the following command to restore the default CuPy malloc
        cupy.cuda.set_allocator(cupy.get_default_memory_pool().malloc)
    '''
    cuda_malloc = cupy.cuda.memory._malloc
    default_mempool_malloc = cupy.get_default_memory_pool().malloc
    def malloc(size):
        if size >= n_bytes_threshold:
            return cuda_malloc(size)
        return default_mempool_malloc(size)
    cupy.cuda.set_allocator(malloc)

def batched_vec3_norm2(batched_vec3):
    '''
    einsum('gx,gx->g', vec3, vec3) for the (N,3)-array vec3
    '''
    assert type(batched_vec3) is cupy.ndarray
    assert batched_vec3.dtype == cupy.float64
    assert batched_vec3.ndim == 2
    assert batched_vec3.shape[0] == 3 or batched_vec3.shape[1] == 3
    assert batched_vec3.flags.c_contiguous

    order = "c" if batched_vec3.shape[1] == 3 else "f"

    n = batched_vec3.shape[0] if order == "c" else batched_vec3.shape[1]
    assert n != 3, "Ambiguous array order, cannot determine if the array is C or Fortran order from the shape"
    assert n * 3 < np.iinfo(np.int32).max

    if order == "c":
        fn_name = "vec3_norm2_kernel_c_order"
        if fn_name not in _kernel_registery:
            kernel_code = r'''
                extern "C" __global__
                void vec3_norm2_kernel_c_order(const double* __restrict__ vec3, double* __restrict__ norm2, const int n) {
                    const int i = blockDim.x * blockIdx.x + threadIdx.x;
                    if (i >= n) return;
                    const double x = vec3[i * 3 + 0];
                    const double y = vec3[i * 3 + 1];
                    const double z = vec3[i * 3 + 2];
                    norm2[i] = x*x + y*y + z*z;
                }
            '''
            _kernel_registery[fn_name] = cupy.RawKernel(kernel_code, fn_name)
    else:
        fn_name = "vec3_norm2_kernel_f_order"
        if fn_name not in _kernel_registery:
            kernel_code = r'''
                extern "C" __global__
                void vec3_norm2_kernel_f_order(const double* __restrict__ vec3, double* __restrict__ norm2, const int n) {
                    const int i = blockDim.x * blockIdx.x + threadIdx.x;
                    if (i >= n) return;
                    const double x = vec3[n * 0 + i];
                    const double y = vec3[n * 1 + i];
                    const double z = vec3[n * 2 + i];
                    norm2[i] = x*x + y*y + z*z;
                }
            '''
            _kernel_registery[fn_name] = cupy.RawKernel(kernel_code, fn_name)
    kernel = _kernel_registery[fn_name]

    batched_norm2 = cupy.zeros(n, dtype = cupy.float64)
    kernel(((n + 1024 - 1) // 1024,), (1024,), (batched_vec3, batched_norm2, cupy.int32(n)))

    return batched_norm2

cholesky = cusolver.cholesky

def eigh(a, b=None, overwrite=False):
    '''
    Solve a standard or generalized eigenvalue problem for a complex
    Hermitian or real symmetric matrix.

    Note: both a and b matrices are overwritten when overwrite is specified.
    '''
    if b is None:
        if a.shape[0] > 32600:
            if not SCIPY_EIGH_FOR_LARGE_ARRAYS:
                raise RuntimeError('Array is too large for cupy eigh.')
            a = a.get()
            e, c = scipy.linalg.eigh(a, overwrite_a=True)
            e = asarray(e)
            c = asarray(c)
            return e, c
        return cupy.linalg.eigh(a)

    if a.shape[0] > cusolver.MAX_EIGH_DIM:
        if not SCIPY_EIGH_FOR_LARGE_ARRAYS:
            raise RuntimeError(
                f'Array size exceeds the maximum size {cusolver.MAX_EIGH_DIM}.')
        a = a.get()
        b = b.get()
        e, c = scipy.linalg.eigh(a, b, overwrite_a=True)
        e = asarray(e)
        c = asarray(c)
        return e, c

    return cusolver.eigh(a, b, overwrite)

def stack_with_padding(arrays):
    '''
    Stack orbital coefficients, padding zeros to smaller arrays
    '''
    if not arrays:
        raise ValueError("arrays must be a non-empty sequence")

    max_nmo = max(a.shape[1] for a in arrays)
    nao = arrays[0].shape[0]
    dtype = np.result_type(*arrays)
    out = cupy.empty((len(arrays), nao, max_nmo), dtype=dtype)

    for k, a in enumerate(arrays):
        nmo = a.shape[1]
        out[k,:,:nmo] = a
        if nmo < max_nmo:
            out[k,:,nmo:] = 0
    return out

def empty_aligned(shape, dtype, alignment=128):
    '''
    Allocate an array with a memory alignment.

    Args:
        shape : tuple or int
            Shape of the array to allocate.

    Kwargs:
        dtype : Numpy data type.

        alignment : int
            Byte alignment for the underlying device memory pointer.
            128 bytes is optimal for coalesced global memory access on most CUDA
            architectures.

    '''
    dtype = np.dtype(dtype)
    size = int(np.prod(shape))
    nbytes = size * dtype.itemsize + alignment
    buf = cupy.empty(nbytes, dtype=np.uint8)
    offset = (alignment - buf.data.ptr % alignment) % alignment
    return ndarray(shape, dtype, buf[offset:])
