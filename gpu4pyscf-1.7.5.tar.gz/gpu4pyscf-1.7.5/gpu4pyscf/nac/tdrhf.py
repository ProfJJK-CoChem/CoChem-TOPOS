# Copyright 2021-2025 The PySCF Developers. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Nonadiabatic derivetive coupling matrix element calculation is now in experiment.
This module is under development.
"""

from functools import reduce
import cupy as cp
import numpy as np
from pyscf import lib, gto
from pyscf.scf import _vhf
from pyscf.grad import rhf as rhf_grad_cpu
from pyscf import __config__
from gpu4pyscf.lib import logger
from gpu4pyscf.grad import rhf as rhf_grad
from gpu4pyscf.grad import tdrhf as tdrhf_grad
from gpu4pyscf.df import int3c2e
from gpu4pyscf.df.df_jk import (
    _tag_factorize_dm, _DFHF, _make_factorized_dm, _aggregate_dm_factor_l,
    _transpose_dm)
from gpu4pyscf.lib.cupy_helper import contract, asarray, tag_array
from gpu4pyscf.scf import cphf
from gpu4pyscf.lib import utils
from gpu4pyscf.gto.mole import groupby, ATOM_OF
from scipy.optimize import linear_sum_assignment


def match_and_reorder_mos(s12_ao, mo_coeff_b, mo_coeff, threshold=0.4):
    if mo_coeff_b.shape != mo_coeff.shape:
        raise ValueError("Mo coeff b and mo coeff must have the same shape.")
    if s12_ao.shape[0] != s12_ao.shape[1] or s12_ao.shape[0] != mo_coeff_b.shape[0]:
        raise ValueError("S12 ao must be a square matrix with the same shape as mo coeff b.")
    mo_overlap_matrix = mo_coeff_b.T @ s12_ao @ mo_coeff
    abs_mo_overlap = cp.asnumpy(abs(mo_overlap_matrix))
    cost_matrix = -abs_mo_overlap
    below_threshold_mask = abs_mo_overlap < threshold
    infinity_cost = mo_coeff_b.shape[1] + 1
    cost_matrix[below_threshold_mask] = infinity_cost

    row_ind, col_ind = linear_sum_assignment(cost_matrix)

    matching_indices = col_ind

    mo2_reordered = mo_coeff[:, matching_indices]

    final_chosen_overlaps = abs_mo_overlap[row_ind, col_ind]
    invalid_matches_mask = final_chosen_overlaps < threshold

    if np.any(invalid_matches_mask):
        num_invalid = np.sum(invalid_matches_mask)
        print(
            f"{num_invalid} orbital below threshold {threshold}."
            "This may indicate significant changes in the properties of these orbitals between the two structures."
        )
        invalid_indices = np.where(invalid_matches_mask)[0]
        for idx in invalid_indices:
            print(f"Warning: reference coeff #{idx}'s best match is {final_chosen_overlaps[idx]:.4f} (below threshold {threshold})")

    sign_array = np.sign(cp.asnumpy(mo_overlap_matrix[row_ind, col_ind]))
    # mo2_reordered *= sign_array
    return mo2_reordered, matching_indices, sign_array


def get_nacv_ge(td_nac, x_yI, EI, singlet=True, atmlst=None, verbose=logger.INFO):
    """
    Calculate non-adiabatic coupling vectors between ground and excited states.
    Now, only supports for singlet states.
    Ref:
    [1] 10.1063/1.4903986 main reference
    [2] 10.1021/acs.accounts.1c00312
    [3] 10.1063/1.4885817

    Args:
        td_nac (gpu4pyscf.tdscf.rhf.TDA): Non-adiabatic coupling object for TDDFT or TDHF.
        x_yI (tuple): (xI, yI), xI and yI are the eigenvectors corresponding to the excitation and de-excitation.
        EI (float): excitation energy for state I

    Kwargs:
        singlet (bool): Whether calculate singlet states.
        atmlst (list): List of atoms to calculate the NAC.
        verbose (int): Verbosity level.

    Returns:
        nacv (np.ndarray): NAC matrix element.
    """
    if singlet is False:
        raise NotImplementedError('Only supports for singlet states')
    log = logger.new_logger(td_nac, verbose)
    time0 = log.init_timer()

    mol = td_nac.mol
    mf = td_nac.base._scf
    mf_grad = mf.nuc_grad_method()
    mo_coeff = cp.asarray(mf.mo_coeff)
    mo_energy = cp.asarray(mf.mo_energy)
    mo_occ = cp.asarray(mf.mo_occ)
    nao, nmo = mo_coeff.shape
    orbo = mo_coeff[:, mo_occ > 0]
    orbv = mo_coeff[:, mo_occ ==0]
    nocc = orbo.shape[1]
    nvir = orbv.shape[1]

    xI, yI = x_yI
    xI = cp.asarray(xI).reshape(nocc, nvir).T
    if not isinstance(yI, np.ndarray) and not isinstance(yI, cp.ndarray):
        yI = cp.zeros_like(xI)
    yI = cp.asarray(yI).reshape(nocc, nvir).T
    LI = xI-yI    # eq.(83) in Ref. [1]
    t_debug_1 = log.timer_silent(*time0)[2]
    vresp = td_nac.base.gen_response(singlet=None, hermi=1)

    def fvind(x):
        x = orbv.dot(x.reshape(nvir,nocc)) * 2 # *2 for double occupency
        dm = _make_factorized_dm(x, orbo, symmetrize=1)
        v1ao = vresp(dm)
        return reduce(cp.dot, (orbv.T, v1ao, orbo)).ravel()

    z1 = cphf.solve(
        fvind,
        mo_energy,
        mo_occ,
        -LI*1.0*EI, # only one spin, negative in cphf
        max_cycle=td_nac.cphf_max_cycle,
        tol=td_nac.cphf_conv_tol)[0] # eq.(83) in Ref. [1]

    t_debug_2 = log.timer_silent(*time0)[2]
    z1 = z1.reshape(nvir, nocc)
    # z1ao ~ (z1*2 + z1.T*2)*0.5
    z1aoS = _make_factorized_dm(orbv.dot(z1), orbo, symmetrize=1)
    GZS = vresp(z1aoS)
    # eq.(73) in Ref. [1]
    GZS_mo = reduce(cp.dot, (mo_coeff.T, GZS, mo_coeff))
    W = cp.zeros((nmo, nmo))  # eq.(75) in Ref. [1]
    W[:nocc, :nocc] = GZS_mo[:nocc, :nocc]
    zeta0 = mo_energy[nocc:, cp.newaxis]
    zeta0 = z1 * zeta0
    W[:nocc, nocc:] = GZS_mo[:nocc, nocc:] + 0.5*yI.T*EI + 0.5*zeta0.T #* eq.(43), (56), (28) in Ref. [1]
    zeta1 = mo_energy[cp.newaxis, :nocc]
    zeta1 = z1 * zeta1
    W[nocc:, :nocc] = 0.5*xI*EI + 0.5*zeta1
    W = reduce(cp.dot, (mo_coeff, W , mo_coeff.T)) * 2.0

    mf_grad = mf.nuc_grad_method()
    # eq.(50) in Ref. [1]
    dmz1doo = z1aoS
    td_nac._dmz1doo = dmz1doo
    oo0 = _make_factorized_dm(orbo*2, orbo, symmetrize=0)
    t_debug_3 = log.timer_silent(*time0)[2]

    h1 = cp.asarray(mf_grad.get_hcore(mol))  # without 1/r like terms
    s1 = cp.asarray(mf_grad.get_ovlp(mol))
    dh_td = rhf_grad.contract_h1e_dm(mol, h1, dmz1doo, hermi=1)
    ds = rhf_grad.contract_h1e_dm(mol, s1, W, hermi=0)

    dh1e_td = int3c2e.get_dh1e(mol, dmz1doo)  # 1/r like terms
    if len(mol._ecpbas) > 0:
        dh1e_td += rhf_grad.get_dh1e_ecp(mol, dmz1doo)  # 1/r like terms

    if mol._pseudo:
        raise NotImplementedError("Pseudopotential gradient not supported for molecular system yet")
    t_debug_4 = log.timer_silent(*time0)[2]
    j_factor = [1.]
    k_factor = [1.]
    # dmz1doo does equal to its factorization factor_l.dot(factor_r.T) due to
    # the setting dmz1doo.symmetrize = 1. For the density fitting
    # jk_energies_per_atom, an additional factor of two should be applied.
    ejk = td_nac.jk_energies_per_atom(
        [[dmz1doo, oo0]], j_factor, k_factor, sum_results=True) * 2
    t_debug_5 = log.timer_silent(*time0)[2]

    de = dh_td - ds + ejk
    xIao = reduce(cp.dot, (orbo, xI.T, orbv.T))
    yIao = reduce(cp.dot, (orbv, yI, orbo.T))
    dsxy  = _contract_h1e_dm_asymmetric(mol, s1, xIao*EI) * 2
    dsxy += _contract_h1e_dm_asymmetric(mol, s1, yIao*EI) * 2
    dsxy_etf  = rhf_grad.contract_h1e_dm(mol, s1, xIao*EI, hermi=0)
    dsxy_etf += rhf_grad.contract_h1e_dm(mol, s1, yIao*EI, hermi=0)
    de += cp.asnumpy(dh1e_td)
    de_etf = de + dsxy_etf
    de += dsxy
    t_debug_6 = log.timer_silent(*time0)[2]
    if log.verbose >= logger.DEBUG:
        time_list = [0, t_debug_1, t_debug_2, t_debug_3, t_debug_4, t_debug_5, t_debug_6]
        time_list = [time_list[i] - time_list[i-1] for i in range(1, len(time_list))]
        for i, t in enumerate(time_list):
            logger.note(td_nac, f"Time for step {i}: {t[2]*1e-3:.6f}s")
    return de, de/EI, de_etf, de_etf/EI

def _contract_h1e_dm_asymmetric(mol, h1e, dm):
    '''Both the integral and the dm-like tensors in this contraction are
    asymmetric. This leads to the asymmetric characters of NACV
    '''
    assert h1e.ndim == dm.ndim + 1 == 3
    ao_loc = mol.ao_loc
    dims = ao_loc[1:] - ao_loc[:-1]
    atm_id_for_ao = np.repeat(mol._bas[:,ATOM_OF], dims)
    de_partial = cp.einsum('xij,ji->ix', h1e, dm).real
    de_partial = de_partial.get()
    de = groupby(atm_id_for_ao, de_partial, op='sum')
    assert len(de) == mol.natm
    return de

def get_nacv_ee(td_nac, x_yI, x_yJ, EI, EJ, singlet=True, atmlst=None, verbose=logger.INFO):
    """
    Only supports for excited-excited states.
    Quadratic-response-associated terms are all neglected.

    Ref:
    [1] 10.1063/1.4903986 main reference
    [2] 10.1021/acs.accounts.1c00312
    [3] 10.1063/1.4885817

    Args:
        td_nac: TDNAC object
        x_yI: (xI, yI)
            xI and yI are the eigenvectors corresponding to the excitation and de-excitation for state I
        x_yJ: (xJ, yJ)
            xJ and yJ are the eigenvectors corresponding to the excitation and de-excitation for state J
        EI: energy of state I
        EJ: energy of state J

    Keyword args:
        singlet (bool): Whether calculate singlet states.
        atmlst (list): List of atoms to calculate the NAC.
        verbose (int): Verbosity level.
    """
    if singlet is False:
        raise NotImplementedError('Only supports for singlet states')
    log = logger.new_logger(td_nac, verbose)
    time0 = log.init_timer()

    mol = td_nac.mol
    mf = td_nac.base._scf
    mf_grad = mf.nuc_grad_method()
    mo_coeff = cp.asarray(mf.mo_coeff)
    mo_energy = cp.asarray(mf.mo_energy)
    mo_occ = cp.asarray(mf.mo_occ)
    nao, nmo = mo_coeff.shape
    orbo = mo_coeff[:, mo_occ > 0]
    orbv = mo_coeff[:, mo_occ ==0]
    nocc = orbo.shape[1]
    nvir = orbv.shape[1]

    xI, yI = x_yI
    xJ, yJ = x_yJ

    is_tda = False
    xI = cp.asarray(xI).reshape(nocc, nvir).T
    if not isinstance(yI, np.ndarray) and not isinstance(yI, cp.ndarray):
        yI = cp.zeros_like(xI)
        is_tda = True
    yI = cp.asarray(yI).reshape(nocc, nvir).T
    xJ = cp.asarray(xJ).reshape(nocc, nvir).T
    if not isinstance(yJ, np.ndarray) and not isinstance(yJ, cp.ndarray):
        yJ = cp.zeros_like(xJ)
    yJ = cp.asarray(yJ).reshape(nocc, nvir).T

    xpyI = (xI + yI)
    xmyI = (xI - yI)
    xpyJ = (xJ + yJ)
    xmyJ = (xJ - yJ)
    dmxpyI = _make_factorized_dm(orbv.dot(xpyI), orbo, symmetrize=0)
    dmxpyJ = _make_factorized_dm(orbv.dot(xpyJ), orbo, symmetrize=0)
    dmxmyI = _make_factorized_dm(orbv.dot(xmyI), orbo, symmetrize=0)
    dmxmyJ = _make_factorized_dm(orbv.dot(xmyJ), orbo, symmetrize=0)
    td_nac._dmxpyI = dmxpyI
    td_nac._dmxpyJ = dmxpyJ

    rIJoo =-contract('ai,aj->ij', xJ, xI) - contract('ai,aj->ij', yI, yJ)
    rIJvv = contract('ai,bi->ab', xI, xJ) + contract('ai,bi->ab', yJ, yI)
    TIJoo = (rIJoo + rIJoo.T) * 0.5
    TIJvv = (rIJvv + rIJvv.T) * 0.5
    dmzooIJ = reduce(cp.dot, (orbo, TIJoo, orbo.T)) * 2
    dmzooIJ += reduce(cp.dot, (orbv, TIJvv, orbv.T)) * 2
    t_debug_1 = log.timer_silent(*time0)[2]

    # To reduce the cost of evaulating ERIs, process the following get_jk in one call
    #:vj0IJ, vk0IJ = mf.get_jk(mol, dmzooIJ, hermi=0)
    #:vj1I, vk1I = mf.get_jk(mol, (dmxpyI + dmxpyI.T), hermi=0)
    #:vj2I, vk2I = mf.get_jk(mol, (dmxmyI - dmxmyI.T), hermi=0)
    #:vj1J, vk1J = mf.get_jk(mol, (dmxpyJ + dmxpyJ.T), hermi=0)
    #:vj2J, vk2J = mf.get_jk(mol, (dmxmyJ - dmxmyJ.T), hermi=0)
    if not isinstance(mf, _DFHF):
        dm = cp.stack([dmzooIJ, dmxpyI+dmxpyI.T, dmxpyJ+dmxpyJ.T])
        vj, vk = mf.get_jk(mol, dm, hermi=1)
        vj0IJ, vj1I, vj1J = vj
        vk0IJ, vk1I, vk1J = vk
        dm = cp.stack([dmxmyI - dmxmyI.T, dmxmyJ - dmxmyJ.T])
        vk = mf.get_k(mol, dm, hermi=2)
        vk2I, vk2J = vk
    else:
        vj0IJ, vk0IJ = mf.get_jk(mol, _tag_factorize_dm(dmzooIJ, hermi=1), hermi=1)
        if is_tda:
            dm = _aggregate_dm_factor_l([dmxpyI, dmxpyJ])
            vj, vk = mf.get_jk(mol, dm, hermi=0)
            vk2I = vk[0] - vk[0].T
            vk2J = vk[1] - vk[1].T
        else:
            dm = _aggregate_dm_factor_l([dmxpyI, dmxpyJ, dmxmyI, dmxmyJ])
            vj, vk = mf.get_jk(mol, dm, hermi=0)
            vk2I = vk[2] - vk[2].T
            vk2J = vk[3] - vk[3].T
        vj1I = vj[0] * 2
        vj1J = vj[1] * 2
        vk1I = vk[0] + vk[0].T
        vk1J = vk[1] + vk[1].T
    dm = vj = vk = None

    veff0doo = vj0IJ * 2 - vk0IJ
    veff0doo += td_nac.solvent_response(dmzooIJ)
    wvo = reduce(cp.dot, (orbv.T, veff0doo, orbo)) * 2
    veffI = vj1I * 2 - vk1I
    veffI += td_nac.solvent_response(dmxpyI + dmxpyI.T)
    veffI *= 0.5
    veff0mopI = reduce(cp.dot, (mo_coeff.T, veffI, mo_coeff))
    wvo -= contract("ki,ai->ak", veff0mopI[:nocc, :nocc], xpyJ) * 2
    wvo += contract("ac,ai->ci", veff0mopI[nocc:, nocc:], xpyJ) * 2
    veffJ = vj1J * 2 - vk1J
    veffJ += td_nac.solvent_response(dmxpyJ + dmxpyJ.T)
    veffJ *= 0.5
    veff0mopJ = reduce(cp.dot, (mo_coeff.T, veffJ, mo_coeff))
    wvo -= contract("ki,ai->ak", veff0mopJ[:nocc, :nocc], xpyI) * 2
    wvo += contract("ac,ai->ci", veff0mopJ[nocc:, nocc:], xpyI) * 2
    veffI = -vk2I
    veffI *= 0.5
    veff0momI = reduce(cp.dot, (mo_coeff.T, veffI, mo_coeff))
    wvo -= contract("ki,ai->ak", veff0momI[:nocc, :nocc], xmyJ) * 2
    wvo += contract("ac,ai->ci", veff0momI[nocc:, nocc:], xmyJ) * 2
    veffJ = -vk2J
    veffJ *= 0.5
    veff0momJ = reduce(cp.dot, (mo_coeff.T, veffJ, mo_coeff))
    wvo -= contract("ki,ai->ak", veff0momJ[:nocc, :nocc], xmyI) * 2
    wvo += contract("ac,ai->ci", veff0momJ[nocc:, nocc:], xmyI) * 2
    # The up parts are according to eq. (86) and (86) in Ref. [1]

    vresp = td_nac.base.gen_response(singlet=None, hermi=1)
    t_debug_2 = log.timer_silent(*time0)[2]
    def fvind(x):
        x = orbv.dot(x.reshape(nvir,nocc)) * 2 # *2 for double occupency
        dm = _make_factorized_dm(x, orbo, symmetrize=1)
        v1ao = vresp(dm)
        return reduce(cp.dot, (orbv.T, v1ao, orbo)).ravel()

    z1 = cphf.solve(
        fvind,
        mo_energy,
        mo_occ,
        wvo,
        max_cycle=td_nac.cphf_max_cycle,
        tol=td_nac.cphf_conv_tol)[0] # eq.(80) in Ref. [1]
    z1 /= EJ-EI # only one spin, negative in cphf

    t_debug_3 = log.timer_silent(*time0)[2]
    z1ao = _make_factorized_dm(orbv.dot(z1), orbo, symmetrize=1)
    veff = vresp(z1ao)
    fock_mo = cp.diag(mo_energy)
    TFoo = cp.dot(TIJoo, fock_mo[:nocc,:nocc])
    TFov = cp.dot(TIJoo, fock_mo[:nocc,nocc:])
    TFvo = cp.dot(TIJvv, fock_mo[nocc:,:nocc])
    TFvv = cp.dot(TIJvv, fock_mo[nocc:,nocc:])

    # W is calculated, eqs. (75)~(78) in Ref. [1]
    # in which g_{IJ} (86) in Ref. [1] is calculated
    im0 = cp.zeros((nmo, nmo))
    im0[:nocc, :nocc] = reduce(cp.dot, (orbo.T, veff0doo, orbo)) # 1st term in Eq. (81) in Ref. [1]
    im0[:nocc, :nocc]+= TFoo*2.0 # 2nd term in Eq. (81) in Ref. [1]
    im0[:nocc, :nocc]+= contract("ak,ai->ik", veff0mopI[nocc:, :nocc], xpyJ) # 3rd term in Eq. (81) in Ref. [1]
    im0[:nocc, :nocc]+= contract("ak,ai->ik", veff0momI[nocc:, :nocc], xmyJ) # 4th term in Eq. (81) in Ref. [1]
    im0[:nocc, :nocc]+= contract("ak,ai->ik", veff0mopJ[nocc:, :nocc], xpyI) # 5th term in Eq. (81) in Ref. [1]
    im0[:nocc, :nocc]+= contract("ak,ai->ik", veff0momJ[nocc:, :nocc], xmyI) # 6th term in Eq. (81) in Ref. [1]
    im0[:nocc, :nocc]+=rIJoo.T*(EJ-EI) # only gamma^{IJ}(II) in Eq. (29) in Ref. [1] is considered.

    im0[:nocc, nocc:] = reduce(cp.dot, (orbo.T, veff0doo, orbv))
    im0[:nocc, nocc:]+= TFov*2.0
    im0[:nocc, nocc:]+= contract("ab,ai->ib", veff0mopI[nocc:, nocc:], xpyJ)
    im0[:nocc, nocc:]+= contract("ab,ai->ib", veff0momI[nocc:, nocc:], xmyJ)
    im0[:nocc, nocc:]+= contract("ab,ai->ib", veff0mopJ[nocc:, nocc:], xpyI)
    im0[:nocc, nocc:]+= contract("ab,ai->ib", veff0momJ[nocc:, nocc:], xmyI)

    im0[nocc:, :nocc] = TFvo*2
    im0[nocc:, :nocc]+= contract("ij,ai->aj", veff0mopI[:nocc, :nocc], xpyJ)
    im0[nocc:, :nocc]-= contract("ij,ai->aj", veff0momI[:nocc, :nocc], xmyJ)
    im0[nocc:, :nocc]+= contract("ij,ai->aj", veff0mopJ[:nocc, :nocc], xpyI)
    im0[nocc:, :nocc]-= contract("ij,ai->aj", veff0momJ[:nocc, :nocc], xmyI)

    im0[nocc:, nocc:] = TFvv*2.0
    im0[nocc:, nocc:]+= contract("ib,ai->ab", veff0mopI[:nocc, nocc:], xpyJ)
    im0[nocc:, nocc:]-= contract("ib,ai->ab", veff0momI[:nocc, nocc:], xmyJ)
    im0[nocc:, nocc:]+= contract("ib,ai->ab", veff0mopJ[:nocc, nocc:], xpyI)
    im0[nocc:, nocc:]-= contract("ib,ai->ab", veff0momJ[:nocc, nocc:], xmyI)
    im0[nocc:, nocc:]+=rIJvv.T*(EJ-EI)

    im0 = im0*0.5
    im0[:nocc, :nocc]+= reduce(cp.dot, (orbo.T, veff, orbo))*(EJ-EI)*0.5
    im0[:nocc, nocc:]+= reduce(cp.dot, (orbo.T, veff, orbv))*(EJ-EI)*0.5
    im0[:nocc, nocc:]+= cp.dot(fock_mo[nocc:,nocc:],z1).T*(EJ-EI)*0.25
    im0[nocc:, :nocc]+= cp.dot(z1, fock_mo[:nocc,:nocc]*(EJ-EI))*0.25
    # 0.5 * 0.5 first is in the equation,
    # second 0.5 due to z1.
    # The up parts are according to eqs. (75)~(78) in Ref. [1]
    # * It should be noted that, the quadratic response part is omitted!

    im0 = reduce(cp.dot, (mo_coeff, im0, mo_coeff.T))*2
    t_debug_4 = log.timer_silent(*time0)[2]
    mf_grad = td_nac.base._scf.nuc_grad_method()
    s1 = mf_grad.get_ovlp(mol)
    z1aoS = z1ao * ((EJ - EI)/2)
    dmz1doo = z1aoS + dmzooIJ  # P
    td_nac._dmz1doo = dmz1doo
    oo0 = _make_factorized_dm(orbo*2, orbo, symmetrize=0)  # D, the ground state density matrix

    h1 = cp.asarray(mf_grad.get_hcore(mol))  # without 1/r like terms
    s1 = cp.asarray(mf_grad.get_ovlp(mol))
    dh_td = rhf_grad.contract_h1e_dm(mol, h1, dmz1doo, hermi=1)
    ds = rhf_grad.contract_h1e_dm(mol, s1, im0, hermi=0)

    dh1e_td = int3c2e.get_dh1e(mol, dmz1doo)  # 1/r like terms
    if len(mol._ecpbas) > 0:
        dh1e_td += rhf_grad.get_dh1e_ecp(mol, dmz1doo)  # 1/r like terms

    if mol._pseudo:
        raise NotImplementedError("Pseudopotential gradient not supported for molecular system yet")
    t_debug_5 = log.timer_silent(*time0)[2]

    cp.get_default_memory_pool().free_all_blocks()
    if not is_tda:
        # The permutation symmetry in ERIs can be utilized to optimize the
        # following contraction. dmxpyI has a lower rank than dmxpyI+dmxpyI.T.
        # This can reduce the memory requirements in df.jk_energies_per_atom.
        #:j_factor = [1., 1.,  0.]
        #:k_factor = [1., 1., -1.]
        #:hermi = [1, 1, 2]
        #:ejk = td_nac.jk_energies_per_atom(
        #:    [[dmz1doo, oo0],
        #:     [dmxpyI + dmxpyI.T, dmxpyJ + dmxpyJ.T],
        #:     [dmxmyI - dmxmyI.T, dmxmyJ - dmxmyJ.T]],
        #:    j_factor, k_factor, hermi=hermi, sum_results=True) * 2
        j_factor = [1., 2.,  0.]
        k_factor = [1., 2., -2.]
        ejk = td_nac.jk_energies_per_atom(
            [[_tag_factorize_dm(dmz1doo, hermi=1), oo0],
             [dmxpyI, dmxpyJ + dmxpyJ.T],
             [dmxmyI, dmxmyJ - dmxmyJ.T]],
            j_factor, k_factor, sum_results=True) * 2
    else:
        j_factor = [1., 4.]
        k_factor = [1., 4.]
        ejk = td_nac.jk_energies_per_atom(
            [[_tag_factorize_dm(dmz1doo, hermi=1), oo0],
             [dmxpyI, _transpose_dm(dmxpyJ)]],
            j_factor, k_factor, sum_results=True) * 2
    t_debug_6 = log.timer_silent(*time0)[2]

    de = dh_td - ds + ejk

    rIJoo_ao = reduce(cp.dot, (orbo, rIJoo, orbo.T))*2
    rIJvv_ao = reduce(cp.dot, (orbv, rIJvv, orbv.T))*2
    rIJooS_ao = reduce(cp.dot, (orbo, TIJoo, orbo.T))*2
    rIJvvS_ao = reduce(cp.dot, (orbv, TIJvv, orbv.T))*2
    dsxy  = rhf_grad.contract_h1e_dm(mol, s1, rIJoo_ao * (EJ - EI), hermi=1) * .5
    dsxy += rhf_grad.contract_h1e_dm(mol, s1, rIJvv_ao * (EJ - EI), hermi=1) * .5
    dsxy_etf  = rhf_grad.contract_h1e_dm(mol, s1, rIJooS_ao * (EJ - EI), hermi=1) * .5
    dsxy_etf += rhf_grad.contract_h1e_dm(mol, s1, rIJvvS_ao * (EJ - EI), hermi=1) * .5
    de += cp.asnumpy(dh1e_td)  # Eq. (64) in Ref. [1]
    de_etf = de + dsxy_etf
    de += dsxy
    t_debug_7 = log.timer_silent(*time0)[2]
    if log.verbose >= logger.DEBUG:
        time_list = [0, t_debug_1, t_debug_2, t_debug_3, t_debug_4, t_debug_5, t_debug_6, t_debug_7]
        time_list = [time_list[i] - time_list[i-1] for i in range(1, len(time_list))]
        for i, t in enumerate(time_list):
            logger.note(td_nac, f"Time for step {i}: {t*1e-3:.6f}s")
        
    return de, de/(EJ - EI), de_etf, de_etf/(EJ - EI)


class NAC(lib.StreamObject):

    cphf_max_cycle = getattr(__config__, "grad_tdrhf_Gradients_cphf_max_cycle", 50)
    cphf_conv_tol = getattr(__config__, "grad_tdrhf_Gradients_cphf_conv_tol", 1e-8)

    to_cpu = utils.to_cpu
    to_gpu = utils.to_gpu
    device = utils.device

    _keys = {
        "cphf_max_cycle",
        "cphf_conv_tol",
        "mol",
        "base",
        "states",
        "atmlst",
        "de",
        "de_scaled",
        "de_etf",
        "de_etf_scaled",
    }

    def __init__(self, td):
        self.verbose = td.verbose
        self.stdout = td.stdout
        self.mol = td.mol
        self.base = td
        self.states = (0, 1)  # between which the NACV to be computed. 0 means ground state.
        self.atmlst = None
        self.de = None  # Known as CIS Force Matrix Element
        self.de_scaled = None # CIS derivative coupling without ETF
        self.de_etf = None  # CIS Force Matrix Element with ETF
        self.de_etf_scaled = None # Knwon as CIS derivative coupling with ETF

    _write      = rhf_grad_cpu.GradientsBase._write

    def dump_flags(self, verbose=None):
        log = logger.new_logger(self, verbose)
        log.info("\n")
        log.info(
            "******** LR %s gradients for %s ********",
            self.base.__class__,
            self.base._scf.__class__,
        )
        log.info("cphf_conv_tol = %g", self.cphf_conv_tol)
        log.info("cphf_max_cycle = %d", self.cphf_max_cycle)
        log.info(f"States ID = {self.states}")
        log.info("\n")
        return self

    @lib.with_doc(get_nacv_ge.__doc__)
    def get_nacv_ge(self, x_yI, EI, singlet, atmlst=None, verbose=logger.INFO):
        return get_nacv_ge(self, x_yI, EI, singlet, atmlst, verbose)
    @lib.with_doc(get_nacv_ee.__doc__)
    def get_nacv_ee(self, x_yI, x_yJ, EI, EJ, singlet, atmlst=None, verbose=logger.INFO):
        return get_nacv_ee(self, x_yI, x_yJ, EI, EJ, singlet, atmlst, verbose)

    def kernel(self, states=None, singlet=None, atmlst=None):

        logger.warn(self, "This module is under development!!")

        if singlet is None:
            singlet = self.base.singlet
        if atmlst is None:
            atmlst = self.atmlst
        else:
            self.atmlst = atmlst

        if self.verbose >= logger.WARN:
            self.check_sanity()
        if self.verbose >= logger.INFO:
            self.dump_flags()

        if states is None:
            states = self.states
        else:
            self.states = states
        states = sorted(states)

        nstates = len(self.base.e)
        I, J = states
        if I == J:
            raise ValueError("I and J should be different.")
        if I < 0 or J < 0:
            raise ValueError("Excited states ID should be non-negetive integers.")
        elif I > nstates or J > nstates:
            raise ValueError(f"Excited state exceeds the number of states {nstates}.")
        elif I == 0:
            logger.info(self, f"NACV between ground and excited state {J}.")
            xy_I = self.base.xy[J-1]
            E_I = self.base.e[J-1]
            self.de, self.de_scaled, self.de_etf, self.de_etf_scaled \
                = self.get_nacv_ge(xy_I, E_I, singlet, atmlst, verbose=self.verbose)
            self._finalize()
        else:
            logger.info(self, f"NACV between excited state {I} and {J}.")
            xy_I = self.base.xy[I-1]
            E_I = self.base.e[I-1]
            xy_J = self.base.xy[J-1]
            E_J = self.base.e[J-1]
            self.de, self.de_scaled, self.de_etf, self.de_etf_scaled \
                = self.get_nacv_ee(xy_I, xy_J, E_I, E_J, singlet, atmlst, verbose=self.verbose)
            self._finalize()
        return self.de, self.de_scaled, self.de_etf, self.de_etf_scaled

    get_veff = tdrhf_grad.Gradients.get_veff
    jk_energy_per_atom = tdrhf_grad.Gradients.jk_energy_per_atom
    jk_energies_per_atom = tdrhf_grad.Gradients.jk_energies_per_atom

    def _finalize(self):
        if self.verbose >= logger.NOTE:
            logger.note(
                self,
                "--------- %s nonadiabatic derivative coupling for states %d and %d----------",
                self.base.__class__.__name__,
                self.states[0],
                self.states[1],
            )
            self._write(self.mol, self.de, self.atmlst)
            logger.note(
                self,
                "--------- %s nonadiabatic derivative coupling for states %d and %d after E scaled (divided by E)----------",
                self.base.__class__.__name__,
                self.states[0],
                self.states[1],
            )
            self._write(self.mol, self.de_scaled, self.atmlst)
            logger.note(
                self,
                "--------- %s nonadiabatic derivative coupling for states %d and %d with ETF----------",
                self.base.__class__.__name__,
                self.states[0],
                self.states[1],
            )
            self._write(self.mol, self.de_etf, self.atmlst)
            logger.note(
                self,
                "--------- %s nonadiabatic derivative coupling for states %d and %d with ETF after E scaled (divided by E)----------",
                self.base.__class__.__name__,
                self.states[0],
                self.states[1],
            )
            self._write(self.mol, self.de_etf_scaled, self.atmlst)
            logger.note(self, "----------------------------------------------")

    def solvent_response(self, dm):
        return 0.0

    to_gpu = lib.to_gpu

    def reset(self, mol):
        self.base.reset(mol)
        self.mol = mol
        return self

    def as_scanner(nacv_instance, states=None):
        if isinstance(nacv_instance, lib.GradScanner):
            return nacv_instance

        logger.info(nacv_instance, 'Create scanner for %s', nacv_instance.__class__)
        name = nacv_instance.__class__.__name__ + NAC_Scanner.__name_mixin__
        return lib.set_class(NAC_Scanner(nacv_instance, states),
                            (NAC_Scanner, nacv_instance.__class__), name)

    @classmethod
    def from_cpu(cls, method):
        td = method.base.to_gpu()
        out = cls(td)
        out.cphf_max_cycle = method.cphf_max_cycle
        out.cphf_conv_tol = method.cphf_conv_tol
        out.state = method.state
        out.de = method.de
        out.de_scaled = method.de_scaled
        out.de_etf = method.de_etf
        out.de_etf_scaled = method.de_etf_scaled
        return out


def _wfn_overlap(mo1, mo2, c1, c2, ao_ovlp, num_to_consider=5):
    '''
    Approximate the overlap between two CIS wave functions using the largest N
    determinants. If c1 or c2 is None, its wave function is assumed to be the
    ground state  wave fucntion. In this case, the overlap between a CIS wave
    function and the ground state is evaluated.

    References:
    [1] Efficient and Flexible Computation of Many-Electron Wave Function Overlaps.
        F. Plasser, M. Ruckenbauer, S. Mai, M. Oppel, P. Marquetand, L. González
        DOI: 10.1021/acs.jctc.5b01148
    '''
    if c1 is None:
        assert c2 is not None
        return _wfn_overlap_to_ground_state(mo2, mo1, c2, ao_ovlp.T, num_to_consider)

    if c2 is None:
        return _wfn_overlap_to_ground_state(mo1, mo2, c1, ao_ovlp, num_to_consider)

    s = cp.asarray(ao_ovlp)
    mo1 = cp.asarray(mo1)
    mo2 = cp.asarray(mo2)
    c1 = cp.asnumpy(c1)
    c2 = cp.asnumpy(c2)
    s_mo = mo1.T.dot(s).dot(mo2)

    nocc, nvir = c1.shape

    total_s_state = 0.0

    top_indices0_flat = np.argsort(np.abs(c1).ravel())[-num_to_consider:]
    top_indices1_flat = np.argsort(np.abs(c2).ravel())[-num_to_consider:]

    for idx_l, idx_r in zip(top_indices0_flat, top_indices1_flat):
        idxo_l = idx_l // nvir
        idxv_l = idx_l % nvir
        idxo_r = idx_r // nvir
        idxv_r = idx_r % nvir

        s_occ = s_mo[:nocc,:nocc].copy()
        s_occ[idxo_l,:] = s_mo[idxv_l+nocc,:nocc]
        s_occ[:,idxo_r] = s_mo[:nocc,idxv_r+nocc]
        s_occ[idxo_l,idxo_r] = s_mo[idxv_l+nocc,idxv_r+nocc]

        s_state_contribution = float(cp.linalg.det(s_occ)) \
            * c1[idxo_l, idxv_l] * c2[idxo_r, idxv_r] * 2

        total_s_state += s_state_contribution

    return total_s_state

def _wfn_overlap_to_ground_state(mo1, mo2, c1, ao_ovlp, num_to_consider=5):
    '''
    Approximate the overlap between a CIS wave function and ground state at
    another position.
    '''
    s = cp.asarray(ao_ovlp)
    mo1 = cp.asarray(mo1)
    mo2 = cp.asarray(mo2)
    c1 = cp.asnumpy(c1)
    nocc, nvir = c1.shape
    s_mo = mo1.T.dot(s).dot(mo2)

    top_indices0_flat = np.argsort(np.abs(c1).ravel())[-num_to_consider:]
    total_s_state = 0.0
    for idx_l in top_indices0_flat:
        idxo_l = idx_l // nvir
        idxv_l = idx_l % nvir
        s_occ = s_mo[:nocc,:nocc].copy()
        s_occ[idxo_l,:] = s_mo[idxv_l+nocc,:nocc]
        s_state_contribution = float(cp.linalg.det(s_occ)) \
            * c1[idxo_l, idxv_l] * 2**.5
        total_s_state += s_state_contribution

    return total_s_state

class NAC_Scanner(lib.GradScanner):

    _keys = ['sign']

    def __init__(self, nac_instance, states=None):
        lib.GradScanner.__init__(self, nac_instance)
        self.sign = 1.0
        if states is not None:
            self.states = states
        else:
            self.states = nac_instance.states

    def __call__(self, mol_or_geom, states=None, **kwargs):
        from gpu4pyscf.tdscf.ris import RisBase, rescale_spin_free_amplitudes
        mol0 = self.mol.copy()
        mo_coeff0 = cp.asarray(self.base._scf.mo_coeff)
        mo_occ = cp.asarray(self.base._scf.mo_occ)
        nao, nmo = mo_coeff0.shape
        nocc = int((mo_occ > 0).sum())
        nvir = nmo - nocc

        if isinstance(mol_or_geom, gto.MoleBase):
            assert mol_or_geom.__class__ == gto.Mole
            mol = mol_or_geom
        else:
            mol = self.mol.set_geom_(mol_or_geom, inplace=False)

        self.reset(mol)

        if states is None:
            states = self.states
        else:
            self.states = states
        if isinstance(self.base, RisBase):
            if states[0] != 0:
                xi0, yi0 = rescale_spin_free_amplitudes(self.base.xy, states[0]-1)
                xi0 = xi0.reshape(nocc, nvir)
                yi0 = yi0.reshape(nocc, nvir)
            xj0, yj0 = rescale_spin_free_amplitudes(self.base.xy, states[1]-1)
            xj0 = xj0.reshape(nocc, nvir)
            yj0 = yj0.reshape(nocc, nvir)
        else:
            if states[0] != 0:
                xi0, yi0 = self.base.xy[states[0]-1]
            xj0, yj0 = self.base.xy[states[1]-1]

        td_scanner = self.base

        assert td_scanner.device == 'gpu'
        assert self.device == 'gpu'
        td_scanner(mol)

        if states[0] != 0:
            if isinstance(self.base, RisBase):
                xi1, yi1 = rescale_spin_free_amplitudes(self.base.xy, states[0]-1)
                xi1 = xi1.reshape(nocc, nvir)
                yi1 = yi1.reshape(nocc, nvir)
            else:
                xi1, yi1 = self.base.xy[states[0]-1]
        if isinstance(self.base, RisBase):
            xj1, yj1 = rescale_spin_free_amplitudes(self.base.xy, states[1]-1)
            xj1 = xj1.reshape(nocc, nvir)
            yj1 = yj1.reshape(nocc, nvir)
        else:
            xj1, yj1 = self.base.xy[states[1]-1]

        s = asarray(gto.intor_cross('int1e_ovlp', mol0, mol))
        mo_coeff = cp.asarray(self.base._scf.mo_coeff)

        # for the first state
        if states[0] != 0: # excited state
            state_ovlp = _wfn_overlap(mo_coeff0, mo_coeff, xi0, xi1, s)
            if abs(state_ovlp) < 0.3:
                logger.warn(mol, f'Possible state flip detected for state {states[0]}. '
                            f'Overlap with the previous step is {state_ovlp:.3f}.')
            self.sign *= np.sign(state_ovlp)
        else: # ground state
            s_mo_ground = mo_coeff0[:, :nocc].T @ s @ mo_coeff[:, :nocc]
            self.sign *= np.sign(np.linalg.det(cp.asnumpy(s_mo_ground)))
        # for the second state
        state_ovlp = _wfn_overlap(mo_coeff0, mo_coeff, xj0, xj1, s)
        if abs(state_ovlp) < 0.3:
            logger.warn(mol, f'Possible state flip detected for state {states[1]}. '
                        f'Overlap with the previous step is {state_ovlp:.3f}.')
        self.sign *= np.sign(state_ovlp)

        e_tot = self.e_tot

        de, de_scaled, de_etf, de_etf_scaled= self.kernel(**kwargs)
        de = de*self.sign
        de_scaled = de_scaled*self.sign
        de_etf = de_etf*self.sign
        de_etf_scaled = de_etf_scaled*self.sign
        return e_tot, de, de_scaled, de_etf, de_etf_scaled

    @property
    def converged(self):
        td_scanner = self.base
        return all((td_scanner._scf.converged,
                    td_scanner.converged[self.states[0]],
                    td_scanner.converged[self.states[1]]))
