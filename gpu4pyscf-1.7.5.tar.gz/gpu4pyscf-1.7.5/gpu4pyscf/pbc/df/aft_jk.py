# Copyright 2024-2025 The PySCF Developers. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

'''
JK with analytic Fourier transformation
'''

__all__ = [
    'get_j_kpts', 'get_k_kpts', 'get_jk',
    'get_ej_ip1', 'get_ek_ip1',
    'get_ej_strain_deriv', 'get_ek_strain_deriv'
]

import ctypes
import numpy as np
import cupy as cp
from pyscf import lib
from pyscf.pbc.df.df_jk import _format_kpts_band
from pyscf.pbc.lib.kpts_helper import is_zero, group_by_conj_pairs, kk_adapted_iter
from gpu4pyscf.pbc.tools.k2gamma import kpts_to_kmesh
from gpu4pyscf.pbc.df.ft_ao import FTOpt, libpbc
from gpu4pyscf.pbc.df.fft_jk import _format_dms, _format_jks, _ewald_exxdiv_for_G0
from gpu4pyscf.lib.cupy_helper import contract, get_avail_mem, asarray, ndarray
from gpu4pyscf.lib import logger
from gpu4pyscf.gto.mole import SortedCell
from gpu4pyscf.scf.jk import SHM_SIZE
from gpu4pyscf.pbc.lib.kpts_helper import kk_adapted_iter as bvk_kk_adapted_iter
from gpu4pyscf.pbc.lib.kpts_helper import conj_images_in_bvk_cell

def get_j_kpts(mydf, dm_kpts, hermi=1, kpts=None, kpts_band=None):
    if kpts_band is not None:
        return get_j_for_bands(mydf, dm_kpts, hermi, kpts, kpts_band)

    if kpts is None:
        kpts = np.zeros((1,3))
    else:
        kpts = kpts.reshape(-1, 3)

    dm_kpts = cp.asarray(dm_kpts, order='C')
    dms = _format_dms(dm_kpts, kpts)
    n_dm, nkpts, nao = dms.shape[:3]
    vj_kpts = cp.zeros((n_dm,nkpts,nao,nao), dtype=np.complex128)
    kpt_allow = np.zeros(3)
    coulG = mydf.weighted_coulG(kpt_allow, False)
    for Gpq, p0, p1 in mydf.ft_loop(q=kpt_allow, kpts=kpts):
        _update_vj_(vj_kpts, Gpq, dms, coulG[p0:p1])
    vj_kpts *= 1./len(kpts)

    if is_zero(kpts):
        vj_kpts = vj_kpts.real
    return _format_jks(vj_kpts, dm_kpts, kpts_band, kpts)

def _update_vj_(vj_kpts, Gpq, dms, coulG, weight=None):
    r'''Compute the Coulomb matrix
    J_{kl} = \sum_{ij} \sum_G 4\pi/G^2 * FT(\rho_{ij}) IFT(\rho_{kl}) dm_{ji}
    for analytical FT tensor FT(\rho_{ij})
    '''
    rho = contract('nkij,kgij->ng', dms, Gpq.conj())
    if weight is not None:
        coulG = coulG * weight
    vG = coulG * rho

    if vj_kpts.dtype == np.float64:
        vj_kpts += contract('ng,kgij->nkij', vG, Gpq).real
    else:
        vj_kpts += contract('ng,kgij->nkij', vG, Gpq)
    return vj_kpts

def get_j_for_bands(mydf, dm_kpts, hermi=1, kpts=None, kpts_band=None):
    raise NotImplementedError
    if kpts is None:
        kpts = np.zeros((1,3))
    else:
        kpts = kpts.reshape(-1, 3)
    dm_kpts = lib.asarray(dm_kpts, order='C')
    dms = _format_dms(dm_kpts, kpts)
    nset, nkpts, nao = dms.shape[:3]

    kpt_allow = np.zeros(3)
    coulG = mydf.weighted_coulG(kpt_allow, False)
    ngrids = len(coulG)
    rhoG = cp.zeros((nset,ngrids), dtype=np.complex128)

    for Gpq, p0, p1 in mydf.ft_loop(q=kpt_allow, kpts=kpts):
        rhoG[:,p0:p1] += contract('nkij,kLij->nL', dms, Gpq.conj())
    vG = rhoG * coulG
    vG *= 1./len(kpts)

    kpts_band, input_band = _format_kpts_band(kpts_band, kpts), kpts_band
    nband = len(kpts_band)
    vj_kpts = cp.zeros((nset,nband,nao,nao), dtype=np.complex128)
    for Gpq, p0, p1 in mydf.ft_loop(q=kpt_allow, kpts=kpts_band):
        vj_kpts += contract('nL,kLij->nij', vG[:,p0:p1], Gpq)

    if is_zero(kpts_band):
        vj_kpts = vj_kpts.real
    return _format_jks(vj_kpts, dm_kpts, input_band, kpts)

def get_k_kpts(mydf, dm_kpts, hermi=1, kpts=None, kpts_band=None, exxdiv=None, *,
               omega=None, lr_factor=1, sr_factor=1):
    if kpts_band is not None:
        return get_k_for_bands(mydf, dm_kpts, hermi, kpts, kpts_band, exxdiv)

    is_single_kpt = kpts is not None and kpts.ndim == 1
    if kpts is None:
        kpts = np.zeros((1,3))
    else:
        kpts = kpts.reshape(-1, 3)

    log = logger.new_logger(mydf)
    cpu0 = cpu1 = log.init_timer()
    cell = SortedCell.from_cell(mydf.cell)
    mesh = mydf.mesh
    ngrids = np.prod(mesh)
    mo_coeff = getattr(dm_kpts, 'mo_coeff', None)
    mo_occ = getattr(dm_kpts, 'mo_occ', None)
    dm_kpts = cp.asarray(dm_kpts)

    bvk_kmesh = kpts_to_kmesh(cell, kpts, rcut=cell.rcut+10, bound_by_supmol=False)
    log.debug('bvk_kmesh = %s', bvk_kmesh)
    bvk_ncells = np.prod(bvk_kmesh)

    nao1 = cell.nao
    dms = _format_dms(dm_kpts, kpts)
    n_dm, nkpts, nao = dms.shape[:3]
    vk_kpts = cp.zeros((n_dm,nkpts,nao1,nao1), dtype=np.complex128)
    weight = 1. / nkpts
    if (exxdiv == 'ewald' and
        (cell.dimension < 2 or  # 0D and 1D are computed with inf_vacuum
         (cell.dimension == 2 and cell.low_dim_ft_type == 'inf_vacuum'))):
        raise NotImplementedError

    if bvk_ncells == nkpts:
        kpt_iters = ((kpts[kp], ki_idx, kj_idx, kp==kp_conj)
                     for kp, kp_conj, ki_idx, kj_idx in bvk_kk_adapted_iter(bvk_kmesh))
        t_rev_pairs = conj_images_in_bvk_cell(bvk_kmesh, return_pair=True)
    else:
        kpt_iters = kk_adapted_iter(cell, kpts)
        t_rev_pairs = group_by_conj_pairs(cell, kpts, return_kpts_pairs=False)
        t_rev_pairs = np.asarray(t_rev_pairs, dtype=np.int32, order='F')
    log.debug1('Num time-reversal pairs %d', len(t_rev_pairs))

    time_reversal_symmetry = mydf.time_reversal_symmetry
    if time_reversal_symmetry:
        for k, k_conj in t_rev_pairs:
            if k != k_conj and abs(dms[:,k_conj] - dms[:,k].conj()).max() > 1e-6:
                time_reversal_symmetry = False
                log.debug2('Disable time_reversal_symmetry')
                break

    if time_reversal_symmetry:
        k_to_compute = np.zeros(nkpts, dtype=np.int8)
        k_to_compute[t_rev_pairs[:,0]] = 1
    else:
        k_to_compute = np.ones(nkpts, dtype=np.int8)

    Gpq_unit = nao1**2*bvk_ncells
    if mo_coeff is None:
        dms = cell.apply_C_mat_CT(dms.reshape(-1,nao,nao))
        dms = dms.reshape(n_dm, nkpts, nao1, nao1)
        if dms.dtype != vk_kpts.dtype:
            dms = dms.astype(vk_kpts.dtype)
        update_vk = _update_vk_

        unit = (Gpq_unit * 2 + # Gpq and Gpq_conj
                Gpq_unit + # Gpq_conj[kj_idx]
                n_dm*nkpts*nao1**2) # contract('ngij,snjk->sngik', Gpq, dms)
    else:
        # dm ~= dm_factor * dm_factor.T
        # mo_coeff, mo_occ may not be a list of aligned array if
        # remove_lin_dep was applied to scf object.
        # We assume they are of the same length in this version.
        mo_coeff = cp.asarray(mo_coeff)
        mo_occ = cp.asarray(mo_occ)
        if is_single_kpt:
            if mo_coeff.ndim == 3:
                mo_coeff = mo_coeff[:,None]
                mo_occ = mo_occ[:,None]
            else:
                mo_coeff = mo_coeff[None]
                mo_occ = mo_occ[None]
        nocc = int((mo_occ > 0).sum(axis=-1).max().get())
        if mo_coeff.ndim == 4:  # KUHF
            occs = cp.array(mo_occ[:,:,:nocc], dtype=np.float64)
            dm_factor = cell.apply_C_dot(mo_coeff[:,:,:,:nocc].reshape(-1,nao,nocc), axis=1)
            dm_factor = cp.asarray(dm_factor.reshape(n_dm,nkpts,nao1,nocc),
                                   dtype=np.complex128, order='C')
        else:  # KRHF
            occs = cp.asarray(mo_occ[None,:,:nocc], dtype=np.float64)
            dm_factor = cell.apply_C_dot(mo_coeff[:,:,:nocc].reshape(-1,nao,nocc), axis=1)
            dm_factor = cp.asarray(dm_factor.reshape(1,nkpts,nao1,nocc),
                                   dtype=np.complex128, order='C')
        dm_factor *= cp.sqrt(occs)[:,:,None,:]
        dms, dm_factor = dm_factor, None

        unit = (Gpq_unit * 2 + # Gpq and Gpq_conj
                n_dm*nkpts*nao1*nocc*2) # contract('ngij,snjk->sngik', Gpq, dms)

        log.debug2('time_reversal_symmetry = %s bvk_ncells = %d '
                   'cell0_nao = %d nocc = %d n_dm = %d',
                   time_reversal_symmetry, bvk_ncells, nao, nocc, n_dm)
        update_vk = _update_vk_dmf
    log.debug2('set update_vk to %s', update_vk)

    ft_opt = FTOpt(cell, bvk_kmesh)
    # permutation_symmetry between bra-in-cell0 and ket-in-bvkcell currently
    # only supports the complete set of kpts within MP mesh.
    ft_opt.permutation_symmetry = bvk_ncells == nkpts
    ft_kern = ft_opt.gen_ft_kernel(transform_ao=False, kpts=kpts)

    Gv, Gvbase, kws = cell.get_Gv_weights(mesh)
    avail_mem = int(get_avail_mem(exclude_memory_pool=True) * .9)
    avail_mem -= n_dm*nkpts*nao1**2 * 16 # intermediates for vk or dms
    Gblksize = max(16, int(avail_mem/(16*unit))//8*8)
    Gblksize = min(Gblksize, ngrids, 16384)
    log.debug1('Gblksize = %d', Gblksize)

    Gpq_buf = cp.empty(unit*Gblksize + n_dm*nkpts*nao1**2, dtype=np.complex128)
    buf = Gpq_buf[Gpq_unit*Gblksize:]
    for group_id, (kpt, ki_idx, kj_idx, self_conj) in enumerate(kpt_iters):
        vkcoulG = mydf.weighted_coulG(kpt, exxdiv, mesh, omega, kpts,
                                      lr_factor=lr_factor, sr_factor=sr_factor)
        vkcoulG *= weight
        for p0, p1 in lib.prange(0, ngrids, Gblksize):
            log.debug3('update_vk [%s:%s]', p0, p1)
            Gpq = ft_kern(Gv[p0:p1], kpt, kj_idx=kj_idx, out=Gpq_buf, buf=buf)
            update_vk(vk_kpts, Gpq, dms, vkcoulG[p0:p1], ki_idx, kj_idx,
                      not self_conj, k_to_compute, t_rev_pairs, buf)
            Gpq = None
        cpu1 = log.timer_debug1(f'get_k_kpts group {group_id}', *cpu1)

    if is_zero(kpts) and not np.iscomplexobj(dm_kpts):
        vk_kpts = vk_kpts.real

    if time_reversal_symmetry:
        for k, k_conj in t_rev_pairs:
            if k != k_conj:
                vk_kpts[:,k_conj] = vk_kpts[:,k].conj()
    vk_kpts = cell.apply_CT_mat_C(vk_kpts.reshape(-1,nao1,nao1))
    log.timer_debug1('get_k_kpts', *cpu0)
    return vk_kpts.reshape(dm_kpts.shape)

def get_k_for_bands(mydf, dm_kpts, hermi=1, kpts=None, kpts_band=None,
                    exxdiv=None):
    raise NotImplementedError

def _allocate(shape, dtype, buf):
    a = ndarray(shape, dtype, buffer=buf)
    return a, buf[a.size:]

def _allocate_like(a, buf):
    return _allocate(a.shape, a.dtype, buf)

def _update_vk_(vk, Gpq, dms, wcoulG, kpti_idx, kptj_idx, swap_2e,
                k_to_compute, t_rev_pairs, buf):
    '''
    contraction for exchange matrices:
    '''
    n_dm, _, nao = dms.shape[:3]
    ngrids = Gpq.shape[1]
    Gpq_conj, buf = _allocate_like(Gpq, buf)
    if Gpq.dtype == np.float64:
        assert dms.dtype == vk.dtype == np.float64
        #:Gpq_conj = Gpq * wcoulG[:,None,None]
        cp.multiply(Gpq, wcoulG[:,None,None], out=Gpq_conj)
    else:
        assert dms.dtype == vk.dtype
        #:Gpq_conj = Gpq.conj()
        cp.conjugate(Gpq, out=Gpq_conj)
        Gpq_conj *= wcoulG[:,None,None]

    k_mask = k_to_compute[kpti_idx] == 1
    ki = kpti_idx[k_mask]
    kj = kptj_idx[k_mask]
    nkj = len(kj)
    if len(kj) == len(Gpq):
        idx = np.empty_like(ki)
        idx[kj] = ki
        tmp, buf1 = _allocate((n_dm,nkj,ngrids,nao,nao), Gpq.dtype, buf)
        tmp1, _ = _allocate((n_dm,nkj,nao,nao), Gpq.dtype, buf1)
        contract('ngij,snjk->sngik', Gpq, dms, out=tmp)
        vk[:,idx] += contract('sngik,nglk->snil', tmp, Gpq_conj, out=tmp1)
    else:
        tmp, buf1 = _allocate((n_dm,nkj,ngrids,nao,nao), Gpq.dtype, buf)
        tmp1, buf1 = _allocate((n_dm,nkj,nao,nao), Gpq.dtype, buf1)
        tmp2, _ = _allocate((nkj,ngrids,nao,nao), Gpq.dtype, buf1)
        #:tmp = contract('ngij,snjk->sngik', Gpq[kj], dms[:,kj])
        #:vk[:,ki] += contract('sngik,nglk->snil', tmp, Gpq_conj[kj])
        cp.take(Gpq, kj, axis=0, out=tmp2)
        cp.take(dms, kj, axis=1, out=tmp1)
        contract('ngij,snjk->sngik', tmp2, tmp1, out=tmp)
        cp.take(Gpq_conj, kj, axis=0, out=tmp2)
        vk[:,ki] += contract('sngik,nglk->snil', tmp, tmp2, out=tmp1)

    if swap_2e:
        k_mask = k_to_compute[kptj_idx] == 1
        ki = kpti_idx[k_mask]
        kj = kptj_idx[k_mask]
        nkj = len(kj)
        if len(ki) == len(Gpq):
            idx = np.empty_like(ki)
            idx[kj] = ki
            tmp, buf1 = _allocate((n_dm,nkj,ngrids,nao,nao), Gpq.dtype, buf)
            tmp1, _ = _allocate((n_dm,nkj,nao,nao), Gpq.dtype, buf1)
            cp.take(dms, idx, axis=1, out=tmp1)
            contract('ngij,snli->snglj', Gpq, tmp1, out=tmp)
            contract('nglk,snglj->snkj', Gpq_conj, tmp, beta=1, out=vk)
        else:
            tmp, buf1 = _allocate((n_dm,nkj,ngrids,nao,nao), Gpq.dtype, buf)
            tmp1, buf1 = _allocate((n_dm,nkj,nao,nao), Gpq.dtype, buf1)
            tmp2, _ = _allocate((nkj,ngrids,nao,nao), Gpq.dtype, buf1)
            cp.take(Gpq, kj, axis=0, out=tmp2)
            cp.take(dms, ki, axis=1, out=tmp1)
            contract('ngij,snli->snglj', tmp2, tmp1, out=tmp)
            cp.take(Gpq_conj, kj, axis=0, out=tmp2)
            vk[:,kj] += contract('nglk,snglj->snkj', tmp2, tmp, out=tmp1)
    return vk

def _update_vk_dmf(vk, Gpq, dmf, wcoulG, kpti_idx, kptj_idx, swap_2e,
                   k_to_compute, t_rev_pairs, buf):
    '''
    dmf is the factorized dm, dm = dmf * dmf.conj().T
    Computing exchange matrices with dmf:
    '''
    n_dm, _, nao, nocc = dmf.shape[:4]
    ngrids = Gpq.shape[1]
    k_mask = k_to_compute[kpti_idx] == 1
    ki = kpti_idx[k_mask]
    kj = kptj_idx[k_mask]
    nkj = len(kj)
    Gpi, buf1 = _allocate((n_dm,nkj,ngrids,nocc,nao), Gpq.dtype, buf)
    if len(ki) == len(Gpq):
        idx = np.empty_like(ki)
        idx[kj] = ki
        ki = idx
        contract('ngij,snjp->sngpi', Gpq, dmf, out=Gpi)
    else:
        tmp, buf2 = _allocate((n_dm,nkj,nao,nocc), Gpq.dtype, buf1)
        tmp1, _ = _allocate((nkj,ngrids,nao,nao), dmf.dtype, buf2)
        cp.take(Gpq, kj, axis=0, out=tmp1)
        cp.take(dmf, kj, axis=1, out=tmp)
        contract('ngij,snjp->sngpi', tmp1, tmp, out=Gpi)
    Gpi_conj, buf1 = _allocate(Gpi.shape, Gpq.dtype, buf1)
    tmp, _ = _allocate((n_dm,nkj,nao,nao), vk.dtype, buf1)
    if Gpi.dtype == np.float64:
        assert dmf.dtype == vk.dtype == np.float64
        #:Gpi_conj = Gpi * wcoulG[:,None,None]
        cp.multiply(Gpi, wcoulG[:,None,None], out=Gpi_conj)
    else:
        #:Gpi_conj = Gpi.conj()
        cp.conjugate(Gpi, out=Gpi_conj)
        Gpi_conj *= wcoulG[:,None,None]
    vk[:,ki] += contract('sngpi,sngpj->snij', Gpi, Gpi_conj, out=tmp)

    if swap_2e:
        k_mask = k_to_compute[kptj_idx] == 1
        ki = kpti_idx[k_mask]
        kj = kptj_idx[k_mask]
        nkj = len(kj)
        Gpi, buf1 = _allocate((n_dm,nkj,ngrids,nocc,nao), Gpq.dtype, buf)
        if len(ki) == len(Gpq):
            idx = np.empty_like(ki)
            idx[kj] = ki
            dmf_ki, _ = _allocate((n_dm,nkj,nao,nocc), dmf.dtype, buf1)
            cp.take(dmf, idx, axis=1, out=dmf_ki)
            dmf_ki.imag *= -1 # conj(dmf_ki)
            contract('ngij,snip->sngpj', Gpq, dmf_ki, out=Gpi)
            #:Gpi_conj = Gpi.conj()
            Gpi_conj, _ = _allocate_like(Gpi, buf1)
            cp.conjugate(Gpi, out=Gpi_conj)
            Gpi_conj *= wcoulG[:,None,None]
            contract('sngpi,sngpj->snij', Gpi_conj, Gpi, beta=1, out=vk)
        else:
            dmf_ki, buf2 = _allocate((n_dm,nkj,nao,nocc), dmf.dtype, buf1)
            tmp1, _ = _allocate((nkj,ngrids,nao,nao), Gpq.dtype, buf2)
            cp.take(Gpq, kj, axis=0, out=tmp1)
            cp.take(dmf, ki, axis=1, out=dmf_ki)
            dmf_ki.imag *= -1 # conj(dmf_ki)
            contract('ngij,snip->sngpj', tmp1, dmf_ki, out=Gpi)
            #:Gpi_conj = Gpi.conj()
            tmp, buf2 = _allocate((n_dm,nkj,nao,nao), vk.dtype, buf1)
            Gpi_conj, _ = _allocate_like(Gpi, buf2)
            cp.conjugate(Gpi, out=Gpi_conj)
            Gpi_conj *= wcoulG[:,None,None]
            vk[:,kj] += contract('sngpi,sngpj->snij', Gpi_conj, Gpi, out=tmp)
    return vk

def get_ej_ip1(mydf, dm, kpts=None):
    '''The first order energy derivatives from Coulomb matrix'''
    log = logger.new_logger(mydf)
    cell = mydf.cell
    if kpts is None:
        kpts = np.zeros((1,3))
        kmesh = np.array([1, 1, 1])
    else:
        kpts = kpts.reshape(-1, 3)
        kmesh = kpts_to_kmesh(cell, kpts)
    is_gamma_point = is_zero(kpts)
    dms = _format_dms(dm, kpts)
    n_dm, nkpts, nao = dms.shape[:3]
    assert nkpts == len(kpts)
    if n_dm == 2:
        dms = dms[0] + dms[1]
    elif n_dm > 1:
        raise NotImplementedError

    ft_opt = FTOpt(cell, kmesh)
    ft_kern = ft_opt.gen_ft_kernel(transform_ao=False, kpts=kpts)

    cell = ft_opt.cell
    dms = cp.asarray(dms.reshape(-1,nao,nao))
    dms = cell.apply_C_mat_CT(dms)
    if is_gamma_point:
        dms_bvkcell = cp.asarray(dms.real, order='C')
    else:
        expLk = cp.exp(1j*cp.asarray(ft_opt.bvkmesh_Ls).dot(cp.asarray(kpts).T))
        dms_bvkcell = contract('Lk,kpq->Lpq', expLk, dms)
        assert abs(dms_bvkcell.imag).max() < 1e-6
        dms_bvkcell = cp.asarray(dms_bvkcell.real, order='C')
        expLk = None

    bvk_ncells = np.prod(ft_opt.bvk_kmesh)
    nao = cell.nao
    Gv = cell.get_Gv(mydf.mesh)
    ngrids = len(Gv)
    # memory buffer required by eval_ft
    avail_mem = get_avail_mem(exclude_memory_pool=True) * .8
    blksize = max(16, int(avail_mem/(nao**2*bvk_ncells*16*2))//16*16)
    blksize = min(blksize, ngrids, 16384)

    wcoulG = mydf.weighted_coulG()

    bas_ij_idx, bas_ij_img_idx, shl_pair_offsets = _generate_shl_pairs(ft_opt)
    nbatches_shl_pair = len(shl_pair_offsets) - 1
    aft_envs = ft_opt.aft_envs

    shm_size = _estimate_max_shm_size(cell, (1,0))
    log.debug('bas_ij_idx=%d nbatches=%d shm_size=%d blksize=%d',
              len(bas_ij_idx), nbatches_shl_pair, shm_size, blksize)

    kern = libpbc.PBC_ft_aopair_ej_ip1
    ej = cp.zeros((cell.natm, 3))
    for p0, p1 in lib.prange(0, ngrids, blksize):
        nGv = p1 - p0
        # TODO: Gpq are transformed to the k-points adapted representation
        # This transformation can be skipped.
        Gpq = ft_kern(Gv[p0:p1])
        Gpq = Gpq.transpose(0,2,3,1)
        vG = contract('kji,kijg->g', dms, Gpq).conj()
        vG *= wcoulG[p0:p1]
        GvT = cp.asarray(Gv[p0:p1].T.ravel())
        Gpq = None
        err = kern(
            ctypes.cast(ej.data.ptr, ctypes.c_void_p),
            ctypes.cast(dms_bvkcell.data.ptr, ctypes.c_void_p),
            ctypes.cast(vG.data.ptr, ctypes.c_void_p),
            ctypes.cast(GvT.data.ptr, ctypes.c_void_p),
            ctypes.byref(aft_envs),
            ctypes.c_int(nbatches_shl_pair),
            ctypes.c_int(nGv),
            ctypes.c_int(shm_size),
            ctypes.cast(bas_ij_idx.data.ptr, ctypes.c_void_p),
            ctypes.cast(bas_ij_img_idx.data.ptr, ctypes.c_void_p),
            ctypes.cast(shl_pair_offsets.data.ptr, ctypes.c_void_p),
            ctypes.c_int(int(ft_opt.permutation_symmetry)))
        if err != 0:
            raise RuntimeError('PBC_ft_aopair_ej_ip1 failed')
    if not ft_opt.permutation_symmetry:
        ej *= .5
    ej = ej.get()
    ej /= nkpts**2
    return ej

def get_ek_ip1(mydf, dm, kpts=None, exxdiv=None, *,
               omega=None, lr_factor=1, sr_factor=1):
    '''The first order energy derivatives from exact exchange'''
    log = logger.new_logger(mydf)
    cpu0 = cpu1 = log.init_timer()
    cell = mydf.cell
    if kpts is None:
        kpts = np.zeros((1,3))
        kmesh = np.array([1, 1, 1])
    else:
        kpts = kpts.reshape(-1, 3)
        kmesh = kpts_to_kmesh(cell, kpts, rcut=cell.rcut+10, bound_by_supmol=False)
    bvk_ncells = np.prod(kmesh)
    is_gamma_point = is_zero(kpts)
    dms = _format_dms(dm, kpts)
    n_dm, nkpts, nao = dms.shape[:3]
    assert nkpts == len(kpts)
    assert bvk_ncells == nkpts
    if n_dm > 2:
        raise NotImplementedError

    ft_opt = FTOpt(cell, kmesh)
    ft_kern = ft_opt.gen_ft_kernel(transform_ao=False)

    cell = ft_opt.cell
    dms = cp.asarray(dms.reshape(-1,nao,nao))
    dms = cell.apply_C_mat_CT(dms)
    nao = dms.shape[-1]
    dms = dms.reshape(n_dm,nkpts,nao,nao)

    if not is_gamma_point:
        expLk = cp.exp(1j*cp.asarray(ft_opt.bvkmesh_Ls).dot(cp.asarray(kpts).T))

    Gv = cell.get_Gv(mydf.mesh)
    ngrids = len(Gv)
    # memory buffer required by ft_kern
    avail_mem = get_avail_mem(exclude_memory_pool=True) * .8
    blksize = int(avail_mem/(nao**2*bvk_ncells*16*2))//16*16
    if blksize == 0:
        raise RuntimeError('Insufficient GPU memory')
    blksize = min(blksize, ngrids)

    bas_ij_idx, bas_ij_img_idx, shl_pair_offsets = _generate_shl_pairs(ft_opt)
    nbatches_shl_pair = len(shl_pair_offsets) - 1
    aft_envs = ft_opt.aft_envs

    shm_size = _estimate_max_shm_size(cell, (1,0))
    log.debug('bas_ij_idx=%d nbatches=%d shm_size=%d blksize=%d',
              len(bas_ij_idx), nbatches_shl_pair, shm_size, blksize)

    kern = libpbc.PBC_ft_aopair_ek_ip1
    ek = cp.zeros((cell.natm, 3))
    for group_id, (kp, kp_conj, ki_idx, kj_idx) in enumerate(bvk_kk_adapted_iter(kmesh)):
        kpt = kpts[kp]
        wcoulG = mydf.weighted_coulG(kpt, exxdiv, mydf.mesh, omega, kpts,
                                     lr_factor=lr_factor, sr_factor=sr_factor)
        swap_2e = kp != kp_conj
        for p0, p1 in lib.prange(0, ngrids, blksize):
            nGv = p1 - p0
            #:pqG = ft_kern(Gv[p0:p1], kpt, kpts, kj_idx).transpose(0,2,3,1)
            #:pqG_conj = pqG.conj()
            # pqG.conj() can be computed effectively as
            pqG_conj = ft_kern(-Gv[p0:p1], -kpt, -kpts, kj_idx).transpose(0,2,3,1)

            # Note: PBC_ft_aopair_ek_ip1 kernel only processes the tril part.
            # dms must be symmetric, to make dm_vG symmetric between i and j
            if is_gamma_point:
                tmp = contract('sjk,lkg->sjlg', dms[:,0], pqG_conj[0])
                dm_vG = contract('sjlg,sli->jig', tmp, dms[:,0])
                if ft_opt.permutation_symmetry:
                    dm_vG *= 2
            else:
                # First consider kj-ki=kp, its contribution to energy is
                # einsum(nijG[kj_idx],jk[kj_idx],nlkG*[kj_idx],li[ki_idx])
                # Its derivatives involve two terms.
                # 1. apply derivatives to nlkG*[kj_idx]
                #:tmp = contract('nijg,snjk->snikg', pqG[kj_idx], dms[:,kj_idx])
                #:dm_vG = contract('snikg,snli->nlkg', tmp, dms[:,ki_idx])
                # the output of the contraction between nlkG* and dm_vG is a
                # real number. So we can instead compute its conjugation
                # contract('nlkg,nlkg->', dm_vG.conj(), nlkG)                ...(1)
                # The expLk for index k in nlkG can be combined to dm_vG, as
                #:dm_vG = contract('Ln,nlkg->Lklg', expLk[:,kj_idx].conj(), dm_vG).conj()
                # The PBC_ft_aopair_ek_ip1 kernel will perform the
                # contract('Lklg,lLkg->', dm_vG, pqG-derivative)
                #
                # 2. When applying derivatives to nijG[kj_idx]
                #:tmp = contract('snjk,nlkg->snjlg', dms[:,kj_idx], pqG.conj()[kj_idx])
                #:dm_G1 = contract('snjlg,snli->nijg', tmp, dms[:,ki_idx])   ...(2)
                # Then combine the expLk for index j in nijG[kj_idx] to dm_G1, yielding
                #:dm_vG += contract('Ln,nijg->Ljig', expLk[:,kj_idx], dm_G1)
                #
                # dm_vG.conj() in Eq (1) is identical to the dm_G1 in Eq (2).
                #
                # For kp_conj (=ki-kj), the contribution to energy is
                # einsum(nijG[ki_idx],jk[ki_idx],nlkG*[ki_idx],li[kj_idx])
                # By applying G -> -G, this energy term leads to complex
                # conjugation to the previous case.
                idx = np.empty_like(ki_idx)
                idx[kj_idx] = ki_idx
                tmp = contract('snjk,nlkg->snljg', dms, pqG_conj)
                tmp = contract('snljg,snli->nijg', tmp, dms[:,idx])
                dm_vG = contract('Lk,kijg->Ljig', expLk, tmp)
                # When ft_opt.permutation_symmetry is enabled, PBC_ft_aopair_ek_ip1 kernel
                # only processes the lower triangular parts (p>=q in pLqG). By using the
                # other transformation for nijG
                #     nijG = contract('Ln,jLiG->nijG', expLk[:,ki_idx].conj(), qLpG)
                # the upper triangular part can be folded into the lower triangular parts
                # TODO: the two types of transformation likely produce the same
                # output. Removing the following transformation if this is true.
                if ft_opt.permutation_symmetry:
                    dm_vG += contract('Lk,kijg->Lijg', expLk[:,idx].conj(), tmp)
            if swap_2e:
                dm_vG *= wcoulG[p0:p1] * 2
            else:
                dm_vG *= wcoulG[p0:p1]
            dm_vG = cp.asarray(dm_vG, order='C')

            GvT = cp.asarray((Gv[p0:p1]+kpt).T.ravel())
            err = kern(
                ctypes.cast(ek.data.ptr, ctypes.c_void_p),
                ctypes.cast(dm_vG.data.ptr, ctypes.c_void_p),
                ctypes.cast(GvT.data.ptr, ctypes.c_void_p),
                ctypes.byref(aft_envs),
                ctypes.c_int(nbatches_shl_pair),
                ctypes.c_int(nGv),
                ctypes.c_int(shm_size),
                ctypes.cast(bas_ij_idx.data.ptr, ctypes.c_void_p),
                ctypes.cast(bas_ij_img_idx.data.ptr, ctypes.c_void_p),
                ctypes.cast(shl_pair_offsets.data.ptr, ctypes.c_void_p),
                ctypes.c_int(int(ft_opt.permutation_symmetry)))
            pqG_conj = tmp = dm_vG = None
            if err != 0:
                raise RuntimeError('PBC_ft_aopair_ek_ip1 failed')
        cpu1 = log.timer_debug1(f'get_k_kpts group {group_id}', *cpu1)
    ek *= .5
    ek = ek.get()
    if not is_gamma_point:
        ek /= nkpts**2
    log.timer_debug1('get_ek_ip1', *cpu0)
    return ek

def _generate_shl_pairs(ft_opt):
    img_idx = ft_opt.img_idx
    img_offsets = ft_opt.img_offsets.get()
    img_counts = img_offsets[1:] - img_offsets[:-1]
    bas_ij_idx = []
    bas_ij_img_idx = []
    shl_pair_offsets = []
    sp0 = sp1 = 0
    p0 = p1 = 0
    for (i, j), bas_ij in ft_opt.bas_ij_cache.items():
        p0, p1 = p1, p1 + len(bas_ij)
        img_counts_ij = img_counts[p0:p1]
        bas_ij = np.repeat(bas_ij.get(), img_counts_ij)
        bas_ij_idx.append(cp.asarray(bas_ij, dtype=np.int32))
        bas_ij_img_idx.append(img_idx[img_offsets[p0]:img_offsets[p1]])
        sp0, sp1 = sp1, sp1 + len(bas_ij)
        shl_pair_offsets.append(cp.arange(sp0, sp1, 128, dtype=np.int32))
    shl_pair_offsets.append(np.int32(sp1))
    bas_ij_idx = cp.hstack(bas_ij_idx, dtype=np.int32)
    bas_ij_img_idx = cp.hstack(bas_ij_img_idx, dtype=np.int32)
    shl_pair_offsets = cp.hstack(shl_pair_offsets, dtype=np.int32)
    return bas_ij_idx, bas_ij_img_idx, shl_pair_offsets

def _estimate_max_shm_size(cell, deriv_ij=None):
    if deriv_ij is None:
        deriv_ij = (0, 0)
    i_inc, j_inc = deriv_ij
    lmax = cell.uniq_l_ctr[:,0].max()
    ls = np.arange(lmax+1)
    gx_len = (ls[:,None]+1+i_inc)*(ls+1+j_inc) * 6*32
    nsp_per_block = np.ones_like(gx_len)
    for m in [2, 4, 8]:
        nsp_per_block[(gx_len + 3)*m*8 < SHM_SIZE] = m
    shm_size = (nsp_per_block * (gx_len + 3)).max() * 8
    return shm_size

def get_ej_strain_deriv(mydf, dm, kpts=None, omega=None, get_wcoulG_deriv=None):
    '''Strain derivatives from Coulomb matrix'''
    from gpu4pyscf.pbc.grad import rks_stress
    log = logger.new_logger(mydf)
    cell = mydf.cell
    if kpts is None:
        kpts = np.zeros((1,3))
        kmesh = np.array([1, 1, 1])
    else:
        kpts = kpts.reshape(-1, 3)
        kmesh = kpts_to_kmesh(cell, kpts)
    is_gamma_point = is_zero(kpts)
    dms = _format_dms(dm, kpts)
    n_dm, nkpts, nao = dms.shape[:3]
    assert nkpts == len(kpts)
    if n_dm == 2:
        dms = dms[0] + dms[1]
    elif n_dm > 1:
        raise NotImplementedError

    ft_opt = FTOpt(cell, kmesh)
    ft_kern = ft_opt.gen_ft_kernel(transform_ao=False, kpts=kpts)

    cell = ft_opt.cell
    dms = cp.asarray(dms.reshape(-1,nao,nao))
    dms = cell.apply_C_mat_CT(dms)
    if is_gamma_point:
        dms_bvkcell = cp.asarray(dms.real, order='C')
    else:
        expLk = cp.exp(1j*cp.asarray(ft_opt.bvkmesh_Ls).dot(cp.asarray(kpts).T))
        dms_bvkcell = contract('Lk,kpq->Lpq', expLk, dms)
        assert abs(dms_bvkcell.imag).max() < 1e-6
        dms_bvkcell = cp.asarray(dms_bvkcell.real, order='C')
        expLk = None

    bvk_ncells = np.prod(ft_opt.bvk_kmesh)
    nao = cell.nao
    Gv = cell.get_Gv(mydf.mesh)
    ngrids = len(Gv)
    # memory buffer required by ft_kern
    avail_mem = get_avail_mem(exclude_memory_pool=True) * .8
    blksize = max(16, int(avail_mem/(nao**2*bvk_ncells*16*2))//16*16)
    blksize = min(blksize, ngrids, 16384)

    if get_wcoulG_deriv is None:
        get_wcoulG_deriv = rks_stress._get_weighted_coulG_strain_derivatives
    wcoulG_0, wcoulG_1 = get_wcoulG_deriv(cell, Gv, omega=omega)

    bas_ij_idx, bas_ij_img_idx, shl_pair_offsets = _generate_shl_pairs(ft_opt)
    nbatches_shl_pair = len(shl_pair_offsets) - 1
    aft_envs = ft_opt.aft_envs

    shm_size = _estimate_max_shm_size(cell, (1,0))
    log.debug('bas_ij_idx=%d nbatches=%d shm_size=%d blksize=%d',
              len(bas_ij_idx), nbatches_shl_pair, shm_size, blksize)

    kern = libpbc.PBC_ft_aopair_ej_strain_deriv
    ej = cp.zeros((cell.natm, 3))
    sigma = cp.zeros((3, 3))
    for p0, p1 in lib.prange(0, ngrids, blksize):
        nGv = p1 - p0
        # TODO: Gpq are transformed to the k-points adapted representation in
        # gen_ft_kernel. This transformation can be skipped.
        Gpq = ft_kern(Gv[p0:p1])
        Gpq = Gpq.transpose(0,2,3,1)
        rhoG = contract('kji,kijg->g', dms, Gpq)
        sigma += .25*cp.einsum('xyg,g,g->xy', wcoulG_1[:,:,p0:p1], rhoG.conj(), rhoG).real

        vG = rhoG.conj()
        vG *= wcoulG_0[p0:p1]
        GvT = cp.asarray(Gv[p0:p1].T.ravel())
        Gpq = None
        err = kern(
            ctypes.cast(ej.data.ptr, ctypes.c_void_p),
            ctypes.cast(sigma.data.ptr, ctypes.c_void_p),
            ctypes.cast(dms_bvkcell.data.ptr, ctypes.c_void_p),
            ctypes.cast(vG.data.ptr, ctypes.c_void_p),
            ctypes.cast(GvT.data.ptr, ctypes.c_void_p),
            ctypes.byref(aft_envs),
            ctypes.c_int(nbatches_shl_pair),
            ctypes.c_int(nGv),
            ctypes.c_int(shm_size),
            ctypes.cast(bas_ij_idx.data.ptr, ctypes.c_void_p),
            ctypes.cast(bas_ij_img_idx.data.ptr, ctypes.c_void_p),
            ctypes.cast(shl_pair_offsets.data.ptr, ctypes.c_void_p),
            ctypes.c_int(int(ft_opt.permutation_symmetry)))
        if err != 0:
            raise RuntimeError('PBC_ft_aopair_ej_strain_deriv failed')
    if not ft_opt.permutation_symmetry:
        ej *= .5
    ej = ej.get()
    if not is_gamma_point:
        ej /= nkpts**2
    sigma = sigma.get()
    sigma *= 2 / nkpts**2
    return sigma

def get_ek_strain_deriv(mydf, dm, kpts=None, exxdiv=None, omega=None,
                        get_wcoulG_deriv=None):
    '''Strain derivatives from exact exchange'''
    from gpu4pyscf.pbc.grad import rks_stress
    log = logger.new_logger(mydf)
    cpu0 = cpu1 = log.init_timer()
    cell = mydf.cell
    if kpts is None:
        kpts = np.zeros((1,3))
        kmesh = np.array([1, 1, 1])
    else:
        kpts = kpts.reshape(-1, 3)
        kmesh = kpts_to_kmesh(cell, kpts)
    is_gamma_point = is_zero(kpts)
    dm0 = _format_dms(dm, kpts)
    n_dm, nkpts, nao = dm0.shape[:3]
    assert nkpts == len(kpts)
    if n_dm > 2:
        raise NotImplementedError

    ft_opt = FTOpt(cell, kmesh)
    ft_kern = ft_opt.gen_ft_kernel(transform_ao=False, kpts=kpts)
    cell = ft_opt.cell
    dms = cp.asarray(dm0.reshape(-1,nao,nao))
    dms = cell.apply_C_mat_CT(dms)
    nao = dms.shape[-1]
    dms = dms.reshape(n_dm,nkpts,nao,nao)

    if not is_gamma_point:
        expLk = cp.exp(1j*cp.asarray(ft_opt.bvkmesh_Ls).dot(cp.asarray(kpts).T))

    bvk_ncells = np.prod(ft_opt.bvk_kmesh)
    Gv = cell.get_Gv(mydf.mesh)
    ngrids = len(Gv)
    # memory buffer required by ft_kern
    avail_mem = get_avail_mem(exclude_memory_pool=True) * .8
    blksize = max(16, int(avail_mem/(nao**2*bvk_ncells*16*2))//16*16)
    blksize = min(blksize, ngrids, 16384)

    if get_wcoulG_deriv is None:
        get_wcoulG_deriv = rks_stress._get_weighted_coulG_strain_derivatives

    bas_ij_idx, bas_ij_img_idx, shl_pair_offsets = _generate_shl_pairs(ft_opt)
    nbatches_shl_pair = len(shl_pair_offsets) - 1
    aft_envs = ft_opt.aft_envs

    shm_size = _estimate_max_shm_size(cell, (1,0))
    log.debug('bas_ij_idx=%d nbatches=%d shm_size=%d blksize=%d',
              len(bas_ij_idx), nbatches_shl_pair, shm_size, blksize)

    kern = libpbc.PBC_ft_aopair_ek_strain_deriv
    ek = cp.zeros((cell.natm, 3))
    sigma = cp.zeros((3, 3))
    sigma1 = cp.zeros((3, 3))
    for group_id, (kp, kp_conj, ki_idx, kj_idx) in enumerate(bvk_kk_adapted_iter(kmesh)):
        kpt = kpts[kp]
        Gvk = Gv + kpt
        wcoulG_0, wcoulG_1 = get_wcoulG_deriv(cell, Gvk, omega=omega)

        swap_2e = kp != kp_conj
        for p0, p1 in lib.prange(0, ngrids, blksize):
            nGv = p1 - p0
            Gpq = ft_kern(Gv[p0:p1], kpt, kj_idx=kj_idx)
            Gpq = Gpq.transpose(0,2,3,1)
            Gpq_conj = Gpq.conj()
            # Gpq.conj() can be computed equivalently as
            #Gpq_conj = ft_kern(-Gv[p0:p1], -kpt, -kpts)
            #Gpq_conj = Gpq_conj.transpose(0,2,3,1)

            if is_gamma_point:
                tmp = contract('sjk,lkg->sjlg', dms[:,0], Gpq_conj[0])
                dm_vG = contract('sjlg,sli->jig', tmp, dms[:,0])
                vkG = cp.einsum('pqg,qpg->g', dm_vG, Gpq[0]).real
                tmp = cp.einsum('xyg,g->xy', wcoulG_1[:,:,p0:p1], vkG)
            else:
                # einsum(nijG[kj_idx],jk[kj_idx],nlkG*[kj_idx],li[ki_idx])
                # apply derivatives to nlkG*
                #:tmp = contract('nijg,snjk->snikg', Gpq[kj_idx], dms[:,kj_idx])
                #:tmp = contract('snikg,snli->nklg', tmp, dms[:,ki_idx])
                #:dm_vG = contract('Lk,kpqg->Lpqg', expLk[:,kj_idx].conj(), tmp).conj()
                #:if swap_2e:
                # apply derivatives to nijG. This term is equivalent to the
                # derivatives of nlkG*.
                #:    tmp = contract('snjk,nlkg->snjlg', dms[:,kj_idx], Gpq.conj()[kj_idx])
                #:    tmp = contract('snjlg,snli->njig', tmp, dms[:,ki_idx])
                #:    dm_vG += contract('Lk,kpqg->Lpqg', expLk[:,kj_idx], tmp)
                idx = np.empty_like(ki_idx)
                idx[kj_idx] = ki_idx
                dm_k = contract('snjk,nlkg->snjlg', dms, Gpq_conj)
                dm_k = contract('snjlg,snli->njig', dm_k, dms[:,idx])
                dm_vG = contract('Lk,kpqg->Lpqg', expLk, dm_k)
                vkG = cp.einsum('njig,nijg->g', dm_k, Gpq).real
                tmp = cp.einsum('xyg,g->xy', wcoulG_1[:,:,p0:p1], vkG)
            if swap_2e:
                sigma += tmp * 2
                dm_vG *= wcoulG_0[p0:p1] * 2
            else:
                sigma += tmp
                dm_vG *= wcoulG_0[p0:p1]
            dm_vG = cp.asarray(dm_vG, order='C')

            GvT = cp.asarray(Gvk[p0:p1].T.ravel())
            err = kern(
                ctypes.cast(ek.data.ptr, ctypes.c_void_p),
                ctypes.cast(sigma1.data.ptr, ctypes.c_void_p),
                ctypes.cast(dm_vG.data.ptr, ctypes.c_void_p),
                ctypes.cast(GvT.data.ptr, ctypes.c_void_p),
                ctypes.byref(aft_envs),
                ctypes.c_int(nbatches_shl_pair),
                ctypes.c_int(nGv),
                ctypes.c_int(shm_size),
                ctypes.cast(bas_ij_idx.data.ptr, ctypes.c_void_p),
                ctypes.cast(bas_ij_img_idx.data.ptr, ctypes.c_void_p),
                ctypes.cast(shl_pair_offsets.data.ptr, ctypes.c_void_p),
                ctypes.c_int(int(ft_opt.permutation_symmetry)))
            Gpq = Gpq_conj = tmp = dm_vG = None
            if err != 0:
                raise RuntimeError('PBC_ft_aopair_ek_strain_deriv failed')
        cpu1 = log.timer_debug1(f'get_k_kpts group {group_id}', *cpu1)
    if not ft_opt.permutation_symmetry:
        ek *= .5
    ek = ek.get()
    if not is_gamma_point:
        ek /= nkpts**2
    sigma *= 1. / nkpts**2
    # First *2 due to i>=j symmetry in kernel;
    # second *2 due to (d/dX ij|kl) + (ij|d/dX kl)
    sigma1 *= 2 * 2 / nkpts**2
    sigma += sigma1
    sigma = sigma.get()

    if (exxdiv == 'ewald' and
        (cell.dimension == 3 or
         (cell.dimension == 2 and cell.low_dim_ft_type != 'inf_vacuum'))):
        from gpu4pyscf.pbc.gto import int1e
        cell = mydf.cell
        s0 = int1e.int1e_ovlp(cell, kpts, kmesh)
        k_dm = contract('nkpq,kqr->nkpr', dm0, s0)
        k_dm = contract('nkpr,nkrs->kps', k_dm, dm0)
        ek_G0 = cp.einsum('kij,kji->', s0, k_dm).real.get() / nkpts**2
        exx_0, exx_1 = _exxdiv_ewald_strain_deriv(cell, kpts, omega)
        sigma += exx_1 * ek_G0
        # *2 due to (d/dX ij|kl) + (ij|d/dX kl)
        # scaled by 1/nkpts only instead of 1/nkpts**2 because
        # get_ovlp_strain_deriv has already scaled the output by 1/nkpts
        sigma += 2 / nkpts * exx_0 * int1e.ovlp_strain_deriv(cell, k_dm, kpts)

    # *.5 for the factor 1/2 in Coulomb operator
    sigma *= .5

    log.timer_debug1('get_ek_ip1', *cpu0)
    return sigma

def _exxdiv_ewald_strain_deriv(cell, kpts, omega):
    from pyscf.pbc.tools.pbc import madelung
    from gpu4pyscf.pbc.grad.rks_stress import _finite_diff_cells
    scaled_kpts = kpts.dot(cell.lattice_vectors().T)
    nkpts = len(kpts)
    ewald_G0_response = np.empty((3,3))
    disp = max(1e-5, (cell.precision*.1)**.5)
    for i in range(3):
        for j in range(i+1):
            cell1, cell2 = _finite_diff_cells(cell, i, j, disp)
            kpts1 = scaled_kpts.dot(cell1.reciprocal_vectors(norm_to=1))
            kpts2 = scaled_kpts.dot(cell2.reciprocal_vectors(norm_to=1))
            e1 = nkpts * madelung(cell1, kpts1, omega=omega)
            e2 = nkpts * madelung(cell2, kpts2, omega=omega)
            ewald_G0_response[j,i] = ewald_G0_response[i,j] = (e1-e2)/(2*disp)
    exx_0 = nkpts * madelung(cell, kpts, omega)
    return exx_0, ewald_G0_response

##################################################
#
# Single k-point
#
##################################################

def get_jk(mydf, dm, hermi=1, kpt=np.zeros(3), kpts_band=None, with_j=True,
           with_k=True, exxdiv=None, omega=None):
    '''JK for given k-point'''
    vj = vk = None
    if kpts_band is not None and abs(kpt-kpts_band).max() > 1e-9:
        kpt = np.reshape(kpt, (1,3))
        if with_k:
            vk = get_k_kpts(mydf, dm, hermi, kpt, kpts_band, exxdiv, omega=omega)
        if with_j:
            vj = get_j_kpts(mydf, dm, hermi, kpt, kpts_band)
        return vj, vk

    cell = mydf.cell
    log = logger.new_logger(mydf)
    dm = cp.asarray(dm, order='C')
    dms = _format_dms(dm, kpt.reshape(1, 3))
    nset, _, nao = dms.shape[:3]
    dms = dms.reshape(nset,nao,nao)
    j_real = is_zero(kpt)
    k_real = is_zero(kpt) and not np.iscomplexobj(dms)

    mesh = mydf.mesh
    kpt_allow = np.zeros(3)

    if with_j:
        vjcoulG = mydf.weighted_coulG(kpt_allow, False, mesh)
        vj = cp.zeros((nset,nao,nao), dtype=np.complex128)
    if with_k:
        vkcoulG = mydf.weighted_coulG(kpt_allow, exxdiv, mesh, omega)
        vk = cp.zeros((nset,nao,nao), dtype=np.complex128)

    # TODO: apply ft_opt.coeff to the dms; skip the AO ordering transformation
    # in ft_kern.
    if is_zero(kpt):
        bvk_kmesh = np.ones(3, dtype=int)
    else:
        bvk_kmesh = kpts_to_kmesh(cell, kpt.reshape(1, 3))
    ft_opt = FTOpt(cell, bvk_kmesh)
    ft_kern = ft_opt.gen_ft_kernel(verbose=log)

    Gv, Gvbase, kws = cell.get_Gv_weights(mesh)
    ngrids = len(Gv)
    avail_mem = get_avail_mem(exclude_memory_pool=True) * .8
    Gblksize = max(16, int(avail_mem/(16*nao**2*2)//8*8))
    Gblksize = min(Gblksize, ngrids, 16384)
    log.debug1('Gblksize = %d', Gblksize)

    for p0, p1 in lib.prange(0, ngrids, Gblksize):
        Gpq = ft_kern(Gv[p0:p1], None, kpt.reshape(1, 3))[0]
        if with_j:
            rho = contract('npq,Gpq->nG', dms.conj(), Gpq).conj()
            rho *= vjcoulG[p0:p1]
            vj += contract('nG,Gpq->npq', rho, Gpq)
        if with_k:
            Gpq_conj = Gpq.conj() * vkcoulG[p0:p1,None,None]
            tmp = contract('Gij,njk->nGik', Gpq, dms)
            vk += contract('nGik,Glk->nil', tmp, Gpq_conj)

    if with_j:
        if j_real:
            vj = vj.real
        vj = vj.reshape(dm.shape)
    if with_k:
        # Add ewald_exxdiv contribution because G=0 was not included in the
        # non-uniform grids
        if (exxdiv == 'ewald' and
            (cell.dimension < 2 or  # 0D and 1D are computed with inf_vacuum
             (cell.dimension == 2 and cell.low_dim_ft_type == 'inf_vacuum'))):
            _ewald_exxdiv_for_G0(cell, kpt, dms, vk)
        if k_real:
            vk = vk.real
        vk = vk.reshape(dm.shape)
    return vj, vk
