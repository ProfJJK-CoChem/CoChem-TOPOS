#!/usr/bin/env python
# Copyright 2025 The PySCF Developers. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

r'''
The energy derivatives for the strain tensor e_ij is

                1  d E
    sigma_ij = --- ------
                V  d e_ij

The strain tesnor e_ij describes the transformation for real space coordinates
in the crystal

    \sum_j [\deta_ij + e_ij] R_j  [for j = x, y, z]

Due to numerical errors, the strain tensor may slightly break the symmetry
within the stress tensor. The 6 independent components of the stress tensor

    [e1   e6/2 e5/2]
    [e6/2 e2   e4/2]
    [e5/2 e4/2 e3  ]

is constructed by symmetrizing the strain tensor as follows:

    e1 = e_11
    e2 = e_22
    e3 = e_33
    e6 = e_12 + e_21
    e5 = e_13 + e_31
    e4 = e_32 + e_23

See K. Doll, Mol Phys (2010), 108, 223
'''

import numpy as np
import cupy as cp
import pyscf
from pyscf import lib
from pyscf.pbc.lib.kpts_helper import is_zero
from gpu4pyscf.lib import logger
from gpu4pyscf.pbc.tools import pbc as pbctools
from gpu4pyscf.pbc.dft.gen_grid import UniformGrids
from gpu4pyscf.pbc.df import FFTDF
from gpu4pyscf.pbc.dft.numint import KNumInt, eval_ao_kpts, _GTOvalOpt
from gpu4pyscf.pbc.dft.krkspu import _set_U, _make_minao_lo, reference_mol
from gpu4pyscf.pbc.grad import krks as krks_grad
from gpu4pyscf.pbc.gto import int1e
from gpu4pyscf.pbc.tools.k2gamma import kpts_to_kmesh
from gpu4pyscf.pbc.scf.rsjk import PBCJKMatrixOpt
from gpu4pyscf.lib.cupy_helper import contract, asarray, sandwich_dot
from gpu4pyscf.pbc.grad.rks_stress import (
    strain_tensor_dispalcement,
    _finite_diff_cells,
    _get_weight_strain_derivatives,
    _get_coulG_strain_derivatives,
    _eval_ao_strain_derivatives,
    _get_vpplocG_strain_derivatives,
    _get_pp_nonloc_strain_derivatives,
    ewald)

ALIGNED = 256

def get_ovlp(cell, kpts):
    '''Strain derivatives for overlap matrix
    '''
    disp = 1e-5
    scaled_kpts = kpts.dot(cell.lattice_vectors().T)
    s = []
    for x in range(3):
        for y in range(3):
            cell1, cell2 = _finite_diff_cells(cell, x, y, disp)
            kpts1 = scaled_kpts.dot(cell1.reciprocal_vectors(norm_to=1))
            kpts2 = scaled_kpts.dot(cell2.reciprocal_vectors(norm_to=1))
            s1 = int1e.int1e_ovlp(cell1, kpts1)
            s2 = int1e.int1e_ovlp(cell2, kpts2)
            s.append((s1 - s2) / (2*disp))
    return s

def get_veff(mf_grad, cell, dm, kpts, with_j=False, with_nuc=False):
    '''Strain derivatives for Coulomb and exchange energy with k-point samples
    '''
    mf = mf_grad.base
    with_rsjk = mf.rsjk
    ni = mf._numint

    if with_rsjk is not None:
        assert isinstance(with_rsjk, PBCJKMatrixOpt)
        if with_rsjk.supmol is None:
            with_rsjk.build()
        # TODO: with_nuc should be disabled for all-electron calculations
        sigma = get_vxc(mf_grad, cell, dm, kpts, with_j=False, with_nuc=with_nuc)
        if not ni.libxc.is_hybrid_xc(mf.xc):
            return sigma
        j_factor = 1
        omega, k_lr, k_sr = ni.rsh_and_hybrid_coeff(mf.xc)
        sigma += with_rsjk._get_ejk_sr_strain_deriv(
            dm, kpts, exxdiv=mf.exxdiv, omega=omega,
            j_factor=j_factor, lr_factor=k_lr, sr_factor=k_sr)
        sigma += with_rsjk._get_ejk_lr_strain_deriv(
            dm, kpts, exxdiv=mf.exxdiv, omega=omega,
            j_factor=j_factor, lr_factor=k_lr, sr_factor=k_sr)
    else:
        if not ni.libxc.is_hybrid_xc(mf.xc):
            return get_vxc(mf_grad, cell, dm, kpts, with_j, with_nuc)
        raise NotImplementedError(f'Stress tensor for KHF for {mf.with_df}')
    return sigma

def get_vxc(ks_grad, cell, dm_kpts, kpts, with_j=False, with_nuc=False):
    '''Strain derivatives for Coulomb and Exc with k-point samples

    Kwargs:
        with_j : Whether to include the electron-electron Coulomb interactions
        with_nuc : Whether to include the electron-nuclear Coulomb interactions
    '''
    mf = ks_grad.base
    if dm_kpts is None: dm_kpts = mf.make_rdm1()
    assert cell.low_dim_ft_type != 'inf_vacuum'
    assert cell.dimension != 1

    ni = mf._numint
    assert isinstance(ni, KNumInt)
    if ks_grad.grids is not None:
        grids = ks_grad.grids
    else:
        grids = mf.grids
    assert isinstance(grids, UniformGrids)

    xc_code = mf.xc
    xctype = ni._xc_type(xc_code)
    if xctype == 'LDA':
        deriv = 0
        nvar = 1
    elif xctype == 'GGA':
        deriv = 1
        nvar = 4
    elif xctype == 'MGGA':
        deriv = 1
        nvar = 5
    else:
        raise NotImplementedError

    assert kpts.ndim == 2
    assert dm_kpts.ndim == 3
    if not cell.cart:
        c2s = asarray(cell.cart2sph_coeff())
        dm_kpts = sandwich_dot(dm_kpts, c2s.T)
        # Ensure all AOs are evaluated in the Cartesian GTOs as ao_ks strain
        # derivatives currently supports Cartesian format only
        cell = cell.copy()
        cell.cart = True
    nkpts, nao = dm_kpts.shape[:2]
    assert nkpts == len(kpts)

    grids_idx = grids.argsort(tile=8)
    grids_coords = grids.coords[grids_idx]
    ngrids = len(grids_coords)
    mesh = grids.mesh
    weight_0, weight_1 = _get_weight_strain_derivatives(cell, grids)

    def partial_dot(bra, ket):
        '''conj(ig),ig->g'''
        rho = cp.einsum('ig,ig->g', bra.real, ket.real)
        rho += cp.einsum('ig,ig->g', bra.imag, ket.imag)
        return rho

    eval_gto_opt = _GTOvalOpt(cell, kpts, deriv=deriv+1)
    max_memory = 4e9
    blksize = int((max_memory/16/(nkpts*nvar*10*nao))/ ALIGNED) * ALIGNED
    XY, YY, ZY, XZ, YZ, ZZ = 5, 7, 8, 6, 8, 9

    out = np.zeros((3,3))
    rho0 = cp.zeros((nvar, ngrids))
    rho1 = cp.zeros((3,3, nvar, ngrids))

    for p0, p1 in lib.prange(0, ngrids, blksize):
        coords = cp.asarray(grids_coords[p0:p1].T, order='C').T
        ao_ks = eval_ao_kpts(cell, coords, kpts, deriv=deriv+1, opt=eval_gto_opt)
        ao_ks_strain = _eval_ao_strain_derivatives(
            cell, coords, kpts, deriv=deriv, opt=eval_gto_opt)
        coordsT = coords.T
        for k, dm in enumerate(dm_kpts):
            ao = ao_ks[k].transpose(0,2,1)
            ao_strain = ao_ks_strain[k]
            if xctype == 'LDA':
                ao1 = ao_strain[:,:,0]
                # Adding the response of the grids
                ao1 += contract('xig,yg->xyig', ao[1:4], coordsT)
                c0 = dm.T.dot(ao[0])
                rho0[0,p0:p1] += partial_dot(ao[0], c0).real
                rho1[:,:,0,p0:p1] += contract('xyig,ig->xyg', ao1, c0.conj()).real
            elif xctype == 'GGA':
                ao_strain[:,:,0] += contract('xig,yg->xyig', ao[1:4], coordsT)
                ao_strain[:,:,1] += contract('xig,yg->xyig', ao[4:7], coordsT)
                ao_strain[0,:,2] += contract('ig,yg->yig', ao[XY], coordsT)
                ao_strain[1,:,2] += contract('ig,yg->yig', ao[YY], coordsT)
                ao_strain[2,:,2] += contract('ig,yg->yig', ao[ZY], coordsT)
                ao_strain[0,:,3] += contract('ig,yg->yig', ao[XZ], coordsT)
                ao_strain[1,:,3] += contract('ig,yg->yig', ao[YZ], coordsT)
                ao_strain[2,:,3] += contract('ig,yg->yig', ao[ZZ], coordsT)
                c0 = contract('xig,ij->xjg', ao[:4], dm)
                for i in range(4):
                    rho0[i,p0:p1] += partial_dot(ao[0], c0[i]).real
                # TODO: computing density derivatives in FT form
                rho1[:,:, : ,p0:p1] += contract('xynig,ig->xyng', ao_strain, c0[0].conj()).real
                rho1[:,:,1:4,p0:p1] += contract('xyig,nig->xyng', ao_strain[:,:,0], c0[1:4].conj()).real
            else: # MGGA
                ao_strain[:,:,0] += contract('xig,yg->xyig', ao[1:4], coordsT)
                ao_strain[:,:,1] += contract('xig,yg->xyig', ao[4:7], coordsT)
                ao_strain[0,:,2] += contract('ig,yg->yig', ao[XY], coordsT)
                ao_strain[1,:,2] += contract('ig,yg->yig', ao[YY], coordsT)
                ao_strain[2,:,2] += contract('ig,yg->yig', ao[ZY], coordsT)
                ao_strain[0,:,3] += contract('ig,yg->yig', ao[XZ], coordsT)
                ao_strain[1,:,3] += contract('ig,yg->yig', ao[YZ], coordsT)
                ao_strain[2,:,3] += contract('ig,yg->yig', ao[ZZ], coordsT)
                c0 = contract('xig,ij->xjg', ao[:4], dm)
                for i in range(4):
                    rho0[i,p0:p1] += partial_dot(ao[0], c0[i]).real
                rho0[4,p0:p1] += partial_dot(ao[1], c0[1]).real
                rho0[4,p0:p1] += partial_dot(ao[2], c0[2]).real
                rho0[4,p0:p1] += partial_dot(ao[3], c0[3]).real
                rho1[:,:, :4,p0:p1] += contract('xynig,ig->xyng', ao_strain, c0[0].conj()).real
                rho1[:,:,1:4,p0:p1] += contract('xyig,nig->xyng', ao_strain[:,:,0], c0[1:4].conj()).real
                rho1[:,:,4,p0:p1] += contract('xynig,nig->xyg', ao_strain[:,:,1:4], c0[1:4].conj()).real

    if xctype == 'LDA':
        pass
    elif xctype == 'GGA':
        rho0[1:4] *= 2 # dm should be hermitian
    else: # MGGA
        rho0[1:4] *= 2 # dm should be hermitian
        rho0[4] *= .5 # factor 1/2 for tau
        rho1[:,:,4] *= .5

    rho0 *= 1./nkpts
    # *2 for rho1 because the derivatives were applied to the bra only
    rho1 *= 2./nkpts

    rho0_fft_order = cp.empty_like(rho0)
    rho1_fft_order = cp.empty_like(rho1)
    rho0_fft_order[:,grids_idx] = rho0
    rho1_fft_order[:,:,:,grids_idx] = rho1
    rho0, rho1 = rho0_fft_order, rho1_fft_order

    exc, vxc = ni.eval_xc_eff(xc_code, rho0, 1, xctype=xctype, spin=0)[:2]
    out += contract('xyng,ng->xy', rho1, vxc).real.get() * weight_0
    out += contract('g,g->', rho0[0], exc.ravel()).real.get() * weight_1

    Gv = cell.get_Gv(mesh)
    coulG_0, coulG_1 = _get_coulG_strain_derivatives(cell, Gv)
    rhoG = pbctools.fft(rho0[0], mesh)
    if with_j:
        vR = pbctools.ifft(rhoG * coulG_0, mesh)
        EJ = contract('xyg,g->xy', rho1[:,:,0], vR).real.get() * weight_0 * 2
        EJ += contract('g,g->', rho0[0], vR).real.get() * weight_1
        EJ += contract('xyg,g->xy', coulG_1, rhoG.conj()*rhoG).real.get() * (weight_0/ngrids)
        out += .5 * EJ

    if with_nuc:
        if cell._pseudo:
            vpplocG_0, vpplocG_1 = _get_vpplocG_strain_derivatives(cell, mesh)
            vpplocR = pbctools.ifft(vpplocG_0, mesh).real
            Ene = contract('xyg,g->xy', rho1[:,:,0], vpplocR).real.get()
            Ene += contract('g,xyg->xy', rhoG.conj(), vpplocG_1).real.get() * (1./ngrids)
            Ene += _get_pp_nonloc_strain_derivatives(cell, mesh, dm_kpts, kpts)
        else:
            charge = -cell.atom_charges()
            # SI corresponds to Fourier components of the fractional atomic
            # positions within the cell. It does not respond to the strain
            # transformation
            SI = cell.get_SI(mesh=mesh)
            ZG = asarray(np.dot(charge, SI))
            vR = pbctools.ifft(ZG * coulG_0, mesh).real
            Ene = contract('xyg,g->xy', rho1[:,:,0], vR).real.get()
            Ene += contract('xyg,g->xy', coulG_1, rhoG.conj()*ZG).real.get() * (1./ngrids)
        out += Ene
    return out

def kernel(mf_grad):
    '''Compute the energy derivatives for strain tensor (e_ij)

                1  d E
    sigma_ij = --- ------
                V  d e_ij

    sigma is a asymmetric 3x3 matrix. The symmetric stress tensor in the 6 Voigt
    notation can be transformed from the asymmetric stress tensor

    sigma1 = sigma_11
    sigma2 = sigma_22
    sigma3 = sigma_33
    sigma6 = (sigma_12 + sigma_21)/2
    sigma5 = (sigma_13 + sigma_31)/2
    sigma4 = (sigma_23 + sigma_32)/2

    See K. Doll, Mol Phys (2010), 108, 223
    '''
    assert isinstance(mf_grad, krks_grad.Gradients)
    mf = mf_grad.base
    with_df = mf.with_df
    assert isinstance(with_df, FFTDF)

    log = logger.new_logger(mf_grad)
    t0 = (logger.process_clock(), logger.perf_counter())
    log.debug('Computing stress tensor')

    cell = mf.cell
    dm0 = mf.make_rdm1()
    dme0 = mf_grad.make_rdm1e()
    sigma = ewald(cell)

    kpts = mf.kpts
    kmesh = kpts_to_kmesh(cell, kpts, bound_by_supmol=True)
    sigma -= int1e.ovlp_strain_deriv(cell, dme0, kpts)

    scaled_kpts = kpts.dot(cell.lattice_vectors().T)
    nkpts = len(kpts)
    disp = 1e-5
    for x in range(3):
        for y in range(3):
            cell1, cell2 = _finite_diff_cells(cell, x, y, disp)
            kpts1 = scaled_kpts.dot(cell1.reciprocal_vectors(norm_to=1))
            kpts2 = scaled_kpts.dot(cell2.reciprocal_vectors(norm_to=1))
            t1 = int1e.int1e_kin(cell1, kpts1, kmesh)
            t2 = int1e.int1e_kin(cell2, kpts2, kmesh)
            t1 = cp.einsum('kij,kji->', t1, dm0).real
            t2 = cp.einsum('kij,kji->', t2, dm0).real
            sigma[x,y] += (t1 - t2).get() / (2*disp) / nkpts
    t0 = log.timer_debug1('hcore derivatives', *t0)

    sigma += get_veff(mf_grad, cell, dm0, kpts=kpts, with_j=True, with_nuc=True)
    t0 = log.timer_debug1('Vxc and Coulomb derivatives', *t0)

    if hasattr(mf, 'U_idx'):
        sigma += _hubbard_U_deriv1(mf, dm0, kpts)
        log.timer_debug1('DFT+U')

    sigma /= cell.vol
    if log.verbose >= logger.DEBUG:
        log.debug('Asymmetric strain tensor')
        log.debug('%s', sigma)
    return sigma

def _get_first_order_local_orbitals(cell, minao_ref='MINAO', kpts=None):
    if isinstance(minao_ref, str):
        pcell = reference_mol(cell, minao_ref)
    else:
        pcell = minao_ref
    scaled_kpts = kpts.dot(cell.lattice_vectors().T)
    nkpts = len(kpts)

    nao = cell.nao
    naop = pcell.nao
    if is_zero(kpts):
        C1_minao = cp.empty((3, 3, nkpts, nao, naop))
    else:
        C1_minao = cp.empty((3, 3, nkpts, nao, naop), dtype=np.complex128)
    disp = 1e-5
    for x in range(3):
        for y in range(3):
            cell1, cell2 = _finite_diff_cells(cell, x, y, disp)
            pcell1, pcell2 = _finite_diff_cells(pcell, x, y, disp)
            kpts1 = scaled_kpts.dot(cell1.reciprocal_vectors(norm_to=1))
            kpts2 = scaled_kpts.dot(cell2.reciprocal_vectors(norm_to=1))
            C1 = _make_minao_lo(cell1, pcell1, kpts=kpts1)
            C2 = _make_minao_lo(cell2, pcell2, kpts=kpts2)
            C1_minao[x,y] = (C1 - C2) / (2*disp)
    return C1_minao

def _hubbard_U_deriv1(mf, dm=None, kpts=None):
    assert mf.alpha is None
    assert mf.C_ao_lo is None
    assert mf.minao_ref is not None
    if dm is None:
        dm = mf.make_rdm1()
    cell = mf.cell
    if kpts is None:
        kpts = mf.kpts.reshape(-1, 3)
    nkpts = len(kpts)

    # Construct orthogonal minao local orbitals.
    pcell = reference_mol(cell, mf.minao_ref)
    C_ao_lo = _make_minao_lo(cell, pcell, kpts=kpts)
    U_idx, U_val = _set_U(cell, pcell, mf.U_idx, mf.U_val)[:2]
    U_idx_stack = np.hstack(U_idx)
    C0 = [C_k[:,U_idx_stack] for C_k in C_ao_lo]
    C1_ao_lo = _get_first_order_local_orbitals(cell, pcell, kpts)
    C1 = [C_k[:,:,:,U_idx_stack] for C_k in C1_ao_lo.transpose(2,0,1,3,4)]

    ovlp0 = int1e.int1e_ovlp(cell, kpts)
    ovlp1 = cp.asarray(get_ovlp(cell, kpts))
    nao = ovlp0.shape[-1]
    ovlp1 = ovlp1.reshape(3,3,nkpts,nao,nao).transpose(2,0,1,3,4)
    C_inv = [C_k.conj().T.dot(S_k) for C_k, S_k in zip(C0, ovlp0)]
    dm_deriv0 = [C_k.dot(dm_k).dot(C_k.conj().T) for C_k, dm_k in zip(C_inv, dm)]

    sigma = cp.zeros((3, 3))
    weight = 1. / nkpts
    for k in range(nkpts):
        SC1 = contract('pq,xyqi->xypi', ovlp0[k], C1[k])
        SC1 += contract('xypq,qi->xypi', ovlp1[k], C0[k])
        dm_deriv1 = contract('pj,xyjq->xypq', C_inv[k].dot(dm[k]), SC1)
        i0 = i1 = 0
        for idx, val in zip(U_idx, U_val):
            i0, i1 = i1, i1 + len(idx)
            P0 = dm_deriv0[k][i0:i1,i0:i1]
            P1 = dm_deriv1[:,:,i0:i1,i0:i1]
            sigma += weight * (val * 0.5) * (
                cp.einsum('xyii->xy', P1).real * 2 # *2 for P1+P1.T
                - cp.einsum('xyij,ji->xy', P1, P0).real * 2)
    return sigma.get()
